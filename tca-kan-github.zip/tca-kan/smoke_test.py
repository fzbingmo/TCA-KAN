"""Synthetic sanity check: KAN must fit a known nonlinear function on CPU in seconds.

Passes if (1) training loss drops >90% and (2) KAN beats plain linear regression.
Run:  python smoke_test.py
"""
import numpy as np
import torch

from src.kan import KANRegressor

torch.manual_seed(0)
np.random.seed(0)

# y = sin(3*x0) + x1^2 - 0.5*exp(x2) + noise  (mimics nonlinear feature-wear maps)
N, D = 400, 6
X = np.random.uniform(-1, 1, size=(N, D)).astype(np.float32)
y = (np.sin(3 * X[:, 0]) + X[:, 1] ** 2 - 0.5 * np.exp(X[:, 2])
     + 0.05 * np.random.randn(N)).astype(np.float32)

Xt, yt = torch.from_numpy(X), torch.from_numpy(y)
model = KANRegressor(D, hidden=(16,))
opt = torch.optim.AdamW(model.parameters(), lr=5e-3)

first_loss = None
for epoch in range(300):
    opt.zero_grad()
    loss = torch.nn.functional.mse_loss(model(Xt), yt)
    loss.backward()
    opt.step()
    if first_loss is None:
        first_loss = loss.item()
final_loss = loss.item()

# linear baseline via lstsq
Xb = np.hstack([X, np.ones((N, 1), dtype=np.float32)])
w, *_ = np.linalg.lstsq(Xb, y, rcond=None)
lin_mse = float(np.mean((Xb @ w - y) ** 2))

print(f"KAN   first MSE {first_loss:.4f} -> final MSE {final_loss:.4f}")
print(f"Linear baseline MSE {lin_mse:.4f}")

assert final_loss < 0.1 * first_loss, "FAIL: KAN training did not converge"
assert final_loss < lin_mse, "FAIL: KAN did not beat linear baseline"

# interpretability path must work too
xs, ys = model.layers[0].activation_curves(feature_idx=0)
assert len(xs) == 200 and np.isfinite(ys).all(), "FAIL: activation_curves broken"

print("SMOKE TEST PASSED")
