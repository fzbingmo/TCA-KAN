"""Aggregate run_experiments.py outputs into the paper's E1 table.

Reads results/<dir>/*.json, pools folds x seeds per model, prints
mean +/- 95% CI (t-distribution) for RMSE/MAE in micrometers, both as
a console table and as LaTeX rows ready for TAB-5.
Run:  python aggregate_results.py [--dir results/full_comparison]
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats


def ci95(vals):
    v = np.asarray(vals, dtype=float)
    if len(v) < 2:
        return v.mean(), 0.0
    half = stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return v.mean(), half


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="results/full_comparison")
    ap.add_argument("--per-fold", action="store_true", help="also print per-fold breakdown")
    args = ap.parse_args()

    pool = defaultdict(lambda: defaultdict(list))   # model -> metric -> values
    per_fold = defaultdict(lambda: defaultdict(list))
    files = sorted(Path(args.dir).glob("*.json"))
    if not files:
        raise SystemExit(f"no result json in {args.dir}")
    for f in files:
        r = json.loads(f.read_text())
        for model, m in r["models"].items():
            pool[model]["rmse"].append(m["rmse"] * 1e3)
            pool[model]["mae"].append(m["mae"] * 1e3)
            if "params" in m:
                pool[model]["params"] = m["params"]
            per_fold[(model, r["fold"])]["rmse"].append(m["rmse"] * 1e3)

    print(f"{len(files)} result files\n")
    print(f"{'Model':<22}{'RMSE (um)':<18}{'MAE (um)':<18}{'Params':<10}")
    order = sorted(pool, key=lambda k: np.mean(pool[k]["rmse"]))
    for model in order:
        rm, rh = ci95(pool[model]["rmse"])
        mm, mh = ci95(pool[model]["mae"])
        p = pool[model].get("params", "-")
        print(f"{model:<22}{rm:6.1f} ± {rh:<8.1f}{mm:6.1f} ± {mh:<8.1f}{p:<10}")

    if args.per_fold:
        print("\nper-fold RMSE (um):")
        for (model, fold), m in sorted(per_fold.items()):
            print(f"  {model:<22}{fold}: {np.mean(m['rmse']):.1f}")

    print("\nLaTeX rows (TAB-5):")
    for model in order:
        rm, rh = ci95(pool[model]["rmse"])
        mm, mh = ci95(pool[model]["mae"])
        p = pool[model].get("params", "--")
        print(f"{model} & ${rm:.1f} \\pm {rh:.1f}$ & ${mm:.1f} \\pm {mh:.1f}$ & {p} & \\TBD{{}} & \\TBD{{}} \\\\")


if __name__ == "__main__":
    main()
