"""FIG-1: schematic-led composite for the Machines draft.

Three tiers: (a) the physical milling TCM scenario (spindle, cutter,
workpiece, dynamometer, accelerometers, DAQ, flank-wear zoom);
(b) the TCA-KAN pipeline; (c) the three-protocol validation route.
Pure schematic -- no experiment data touched.
Run:  python fig1_schematic.py [--out DIR]
"""
import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import (Arc, Circle, FancyArrowPatch, FancyBboxPatch,
                                Polygon, Rectangle)

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
    "font.size": 7,
    "axes.spines.right": False,
    "axes.spines.top": False,
    "axes.linewidth": 0.8,
    "legend.frameon": False,
})

C_NEUTRAL = "#4D4D4D"
C_SIGNAL = "#2166AC"
C_ACCENT = "#E08214"
C_BOX = "#DEE7F0"
C_METAL = "#AEB8C2"
C_METAL_DK = "#8A939C"
C_SENSOR = "#BBD4EA"
C_WOOD = "#E3D6BC"
C_GREEN = "#1B7837"


def save_pub(fig, path_stem):
    fig.savefig(f"{path_stem}.pdf", bbox_inches="tight")
    fig.savefig(f"{path_stem}.svg", bbox_inches="tight")
    fig.savefig(f"{path_stem}.png", dpi=300, bbox_inches="tight")


def main(out):
    fig, ax = plt.subplots(figsize=(6.9, 4.83))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 70)
    ax.set_aspect("auto")
    ax.axis("off")

    def rbox(x, y, w, h, fc=C_BOX, ec=C_NEUTRAL, lw=0.8, pad=0.5, ls="-"):
        p = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad={pad}",
                           fc=fc, ec=ec, lw=lw, linestyle=ls)
        ax.add_patch(p)
        return p

    def arrow(p0, p1, rad=0.0, color=C_NEUTRAL, lw=1.0, style="-|>", ms=7):
        ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=ms,
                                     color=color, lw=lw, shrinkA=1, shrinkB=1,
                                     connectionstyle=f"arc3,rad={rad}"))

    # ================= panel (a): milling TCM scenario =================
    ax.text(0.5, 67.5, "(a)", fontsize=9, fontweight="bold", va="top")
    ax.text(17.0, 68.0, "In-process monitoring of the cutting tool",
            fontsize=7, ha="center", va="top", color=C_NEUTRAL)

    # machine table with ground hatching
    ax.add_patch(Rectangle((3, 32.5), 27, 3.0, fc="#C9CDD1", ec=C_NEUTRAL, lw=0.8))
    for xh in np.arange(4, 30, 2.6):
        ax.plot([xh, xh - 1.6], [32.5, 30.9], color=C_NEUTRAL, lw=0.5)
    ax.text(16.5, 34.0, "machine table", ha="center", va="center",
            fontsize=5.6, color=C_NEUTRAL)

    # dynamometer plate
    ax.add_patch(Rectangle((6, 35.5), 21, 3.6, fc=C_SENSOR, ec=C_SIGNAL, lw=0.9))
    ax.text(16.5, 37.3, "3-axis dynamometer  ($F_x, F_y, F_z$)",
            ha="center", va="center", fontsize=5.6, color=C_SIGNAL)

    # workpiece
    ax.add_patch(Rectangle((8, 39.1), 17, 6.6, fc=C_WOOD, ec=C_NEUTRAL, lw=0.8))
    ax.text(13.5, 40.6, "workpiece", ha="center", va="center", fontsize=5.6,
            color=C_NEUTRAL)
    # feed arrow
    arrow((10.5, 43.6), (15.0, 43.6), color=C_NEUTRAL, lw=0.9, ms=6)
    ax.text(12.7, 44.5, "feed", ha="center", fontsize=5.4, color=C_NEUTRAL)

    # accelerometer block on the workpiece
    ax.add_patch(Rectangle((21.2, 45.7), 3.4, 2.6, fc="#F5D9A8", ec=C_ACCENT,
                           lw=0.9))
    ax.text(26.8, 49.6, "accelerometers\n($A_x, A_y, A_z$)", ha="center",
            va="bottom", fontsize=5.6, color="#B26A0F")

    # milling cutter: shank + fluted body, tip touches workpiece top (y=45.7)
    ax.add_patch(Rectangle((13.4, 52.5), 4.6, 6.0, fc=C_METAL_DK,
                           ec=C_NEUTRAL, lw=0.8))  # holder
    ax.add_patch(Rectangle((14.2, 46.0), 3.0, 6.5, fc=C_METAL, ec=C_NEUTRAL,
                           lw=0.8))  # tool body
    for i in range(3):  # flutes
        y0 = 46.6 + i * 2.0
        ax.plot([14.2, 17.2], [y0, y0 + 1.1], color=C_NEUTRAL, lw=0.5)
    # cutting edge tip
    ax.add_patch(Polygon([[14.2, 46.0], [17.2, 46.0], [16.6, 45.0],
                          [14.8, 45.0]], fc=C_METAL, ec=C_NEUTRAL, lw=0.8))
    ax.text(20.0, 55.4, "milling\ncutter", fontsize=5.6, color=C_NEUTRAL,
            ha="left", va="center")

    # spindle housing
    rbox(10.8, 58.6, 9.8, 5.2, fc="#9AA4AD", ec=C_NEUTRAL, pad=0.4)
    ax.text(15.7, 61.2, "spindle", ha="center", va="center", fontsize=6,
            color="white")
    # rotation arrow
    arrow((12.2, 57.4), (19.2, 57.4), rad=-0.55, color=C_NEUTRAL, lw=0.8, ms=5)
    ax.text(21.2, 58.3, "$n$", fontsize=6, color=C_NEUTRAL)

    # chips at the contact zone
    for dx, dy, r in [(2.2, 0.7, 0.45), (3.0, 1.6, 0.4), (2.6, 2.6, 0.35)]:
        ax.add_patch(Circle((17.2 + dx * 0.6, 45.7 + dy), r, fc="none",
                            ec=C_NEUTRAL, lw=0.5))

    # DAQ box, wired to both sensors
    rbox(29.0, 38.5, 6.2, 8.0, fc=C_SENSOR, ec=C_SIGNAL, pad=0.4)
    ax.text(32.1, 42.5, "DAQ\n50 kHz", ha="center", va="center", fontsize=5.8,
            color=C_SIGNAL)
    arrow((27.2, 37.3), (30.4, 38.1), rad=-0.3, color=C_SIGNAL, lw=0.8, ms=5)
    arrow((24.8, 46.8), (30.2, 46.9), rad=0.25, color=C_ACCENT, lw=0.8, ms=5)

    # flank-wear zoom inset
    ax.add_patch(Circle((15.9, 45.6), 1.9, fc="none", ec=C_ACCENT, lw=0.8,
                        linestyle=(0, (2, 1.5))))
    ax.plot([14.2, 4.6], [47.0, 51.6], color=C_ACCENT, lw=0.6,
            linestyle=(0, (2, 1.5)))
    rbox(1.2, 51.8, 8.6, 10.0, fc="white", ec=C_ACCENT, pad=0.4,
         ls=(0, (3, 2)))
    # magnified tool tip with wear land
    ax.add_patch(Polygon([[3.0, 60.8], [7.6, 60.8], [7.6, 55.6], [5.6, 53.4],
                          [3.0, 53.4]], fc=C_METAL, ec=C_NEUTRAL, lw=0.8))
    ax.add_patch(Polygon([[5.6, 53.4], [7.6, 55.6], [7.6, 54.6], [6.4, 53.4]],
                         fc=C_ACCENT, ec="none", alpha=0.85))
    ax.plot([5.6, 7.6], [53.4, 55.6], color=C_NEUTRAL, lw=0.7)
    ax.annotate("", xy=(8.3, 55.7), xytext=(8.3, 53.3),
                arrowprops=dict(arrowstyle="-", color=C_NEUTRAL, lw=0.6))
    ax.plot([7.9, 8.7], [55.7, 55.7], color=C_NEUTRAL, lw=0.6)
    ax.plot([7.9, 8.7], [53.3, 53.3], color=C_NEUTRAL, lw=0.6)
    ax.text(9.2, 54.4, "$VB$", fontsize=6, va="center")
    ax.text(5.4, 62.6, "flank wear", fontsize=5.8, ha="center", color="#B26A0F")

    # ================= panel (b): TCA-KAN pipeline =====================
    ax.text(37.0, 67.5, "(b)", fontsize=9, fontweight="bold", va="top")
    ax.text(69.0, 68.0, "TCA-KAN: temporal-context attention KAN",
            fontsize=7, ha="center", va="top", color=C_NEUTRAL)

    by, bh = 47.5, 12.0  # pipeline row

    def block(x, w, title, tfs=6.0, fc=C_BOX, ec=C_NEUTRAL, tc="black"):
        rbox(x, by, w, bh, fc=fc, ec=ec, pad=0.45)
        ax.text(x + w / 2, by + bh - 1.1, title, ha="center", va="top",
                fontsize=tfs, color=tc)
        return x, x + w

    # raw signals of cut c
    x0, x1 = block(38.5, 8.5, "signals of\ncut $c$", fc="white")
    t = np.linspace(0, 1, 160)
    rng = np.random.default_rng(3)
    for k, (col, f, a) in enumerate([(C_SIGNAL, 9, 1.0), (C_SIGNAL, 13, 0.7),
                                     (C_GREEN, 17, 0.55)]):
        yy = by + 2.6 + k * 2.5 + a * np.sin(2 * np.pi * f * t) \
            + 0.25 * rng.standard_normal(t.size)
        ax.plot(x0 + 0.8 + t * (x1 - x0 - 1.6), yy, color=col, lw=0.6)
    arrow((35.2, 42.5), (39.0, 47.0), rad=-0.3, color=C_SIGNAL, lw=1.0)

    # feature extraction
    arrow((x1 + 0.6, by + bh / 2), (50.4, by + bh / 2), lw=1.0)
    x0, x1 = block(51.0, 8.5, "feature\nextraction $\\psi$")
    for i in range(4):
        for j in range(5):
            ax.add_patch(Rectangle((x0 + 1.7 + j * 1.2, by + 2.0 + i * 1.4),
                                   0.7, 0.7, fc=C_SIGNAL, ec="none"))
    ax.text((x0 + x1) / 2, by - 1.4, "60 = 10 feat. $\\times$ 6 ch.",
            ha="center", va="top", fontsize=5.2, color=C_NEUTRAL)

    # depthwise temporal convolution
    arrow((x1 + 0.6, by + bh / 2), (62.9, by + bh / 2), lw=1.0)
    x0, x1 = block(63.5, 8.5, "depthwise\ntemporal conv")
    for j in range(5):
        fc = C_SIGNAL if j >= 2 else "#C4D6E8"
        ax.add_patch(Rectangle((x0 + 1.3 + j * 1.25, by + 3.3), 0.95, 2.6,
                               fc=fc, ec="none"))
    ax.plot([x0 + 3.7, x0 + 3.7, x0 + 7.6, x0 + 7.6],
            [by + 2.7, by + 2.1, by + 2.1, by + 2.7], color=C_NEUTRAL, lw=0.6)
    ax.text(x0 + 5.6, by + 0.6, "last $k$ cuts", ha="center", fontsize=5.2,
            color=C_NEUTRAL)

    # attention gate
    arrow((x1 + 0.6, by + bh / 2), (75.4, by + bh / 2), lw=1.0)
    x0, x1 = block(76.0, 7.6, "attention\ngate")
    for k, wbar in enumerate([4.6, 2.6, 3.8, 1.6]):
        ax.add_patch(Rectangle((x0 + 1.2, by + 1.9 + k * 1.5), wbar, 0.95,
                               fc=C_ACCENT, ec="none",
                               alpha=0.4 + 0.13 * (4 - k)))
    ax.text((x0 + x1) / 2, by - 1.4, "$\\tilde{h} = g \\odot h$", ha="center",
            va="top", fontsize=5.4, color=C_NEUTRAL)

    # KAN spline head
    arrow((x1 + 0.6, by + bh / 2), (87.4, by + bh / 2), lw=1.0)
    x0, x1 = block(88.0, 10.5, "KAN head:\nB-spline edges")
    nin = [(x0 + 1.8, by + 2.0 + i * 2.1) for i in range(4)]
    nmid = [(x0 + 5.3, by + 2.7 + i * 2.6) for i in range(3)]
    nout = [(x0 + 8.7, by + 4.2)]
    for p in nin + nmid + nout:
        ax.add_patch(Circle(p, 0.32, fc=C_NEUTRAL, ec="none"))
    for pa in nin:
        for pb in nmid:
            arrow(pa, pb, rad=0.35, color=C_SIGNAL, lw=0.5, style="-")
    for pa in nmid:
        for pb in nout:
            arrow(pa, pb, rad=0.35, color=C_SIGNAL, lw=0.5, style="-")

    # outputs
    oy, oh = 29.5, 11.0
    arrow((x0 + 1.5, by - 0.7), (68.5, oy + oh + 0.9), rad=0.22, lw=1.0)
    arrow((x0 + 8.5, by - 0.7), (91.0, oy + oh + 0.9), rad=-0.18, lw=1.0)

    rbox(60.5, oy, 16.5, oh, fc="white", ec=C_NEUTRAL, pad=0.45)
    ax.text(68.75, oy + oh - 1.1, "wear prediction $\\hat{V}_c$", ha="center",
            va="top", fontsize=6.0)
    tt = np.linspace(0, 1, 80)
    wear = 0.25 + 0.5 * tt + 0.25 * tt ** 3
    ax.plot(62.3 + tt * 12.5, oy + 1.8 + wear * 5.2, color=C_SIGNAL, lw=1.0)
    ax.plot(62.3 + tt * 12.5,
            oy + 1.8 + (wear + 0.06 * np.sin(9 * tt)) * 5.2,
            color=C_NEUTRAL, lw=0.7, linestyle=(0, (2, 1.2)))
    ax.annotate("", xy=(75.6, oy + 1.4), xytext=(62.1, oy + 1.4),
                arrowprops=dict(arrowstyle="-", color=C_NEUTRAL, lw=0.5))
    ax.text(74.6, oy + 2.4, "cut", fontsize=5.2, color=C_NEUTRAL)

    rbox(80.5, oy, 18.0, oh, fc="white", ec=C_GREEN, pad=0.45)
    ax.text(89.5, oy + oh - 1.1,
            "interpretable splines $r_i(x)$", ha="center", va="top",
            fontsize=6.0, color=C_GREEN)
    xx = np.linspace(-1, 1, 80)
    ax.plot(82.6 + (xx + 1) * 4.2, oy + 2.8 + 2.6 / (1 + np.exp(-3.2 * xx)),
            color=C_GREEN, lw=1.0)
    ax.plot(82.6 + (xx + 1) * 4.2,
            oy + 2.6 + 2.4 * np.exp(-2.2 * xx ** 2), color=C_GREEN, lw=0.8,
            alpha=0.55)
    ax.text(94.9, oy + 4.4, "$M_i$, $A_i$ audit\nvs. cutting\nphysics",
            ha="center", va="center", fontsize=5.2, color=C_GREEN)

    # ================= panel (c): validation route =====================
    ax.text(0.5, 21.5, "(c)", fontsize=9, fontweight="bold", va="top")
    ax.text(50.0, 22.0, "Validation route", fontsize=7, ha="center",
            va="top", color=C_NEUTRAL)
    arrow((3.0, 17.6), (97.0, 17.6), color=C_NEUTRAL, lw=0.8, ms=6)
    ax.text(50.0, 18.3, "increasing distribution shift", ha="center",
            va="bottom", fontsize=5.6, color=C_NEUTRAL, style="italic")

    def route(x, w, fc, title, l1, l2):
        rbox(x, 4.5, w, 10.5, fc=fc, ec=C_NEUTRAL, pad=0.5)
        ax.text(x + w / 2, 12.9, title, ha="center", va="center",
                fontsize=6.4, fontweight="bold")
        ax.text(x + w / 2, 9.4, l1, ha="center", va="center", fontsize=5.8)
        ax.text(x + w / 2, 6.4, l2, ha="center", va="center", fontsize=5.8,
                color=C_NEUTRAL)

    route(2.5, 28, "#E8EEF6", "E1  within-dataset",
          "PHM2010, leave-one-tool",
          "fixed cutting parameters")
    route(36.0, 28, "#CDDCEC", "E2  unseen parameters",
          "MU-TCM, leave-one-condition",
          "$V_c$, $f_z$, material vary")
    route(69.5, 28, "#AFC9E2", "E3  cross-dataset transfer",
          "PHM2010 $\\leftrightarrow$ MU-TCM",
          "zero-shot / few-shot (10 passes)")
    arrow((31.2, 9.75), (35.3, 9.75), lw=1.0)
    arrow((64.7, 9.75), (68.8, 9.75), lw=1.0)

    fig.subplots_adjust(left=0.01, right=0.99, top=0.99, bottom=0.01)
    save_pub(fig, str(Path(out) / "fig1_framework"))
    plt.close(fig)
    print("FIG-1 written to", out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[1]
                                         / "paper" / "figures"))
    args = ap.parse_args()
    main(args.out)
