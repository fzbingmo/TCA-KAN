"""Recon of a MU-TCM dataset directory: what does full_dataset actually contain?

Parses the encoded filenames (Insert/Edge/Vc/fz/ap/VB/Rep) of every *.mat under
a signals directory and reports the cutting-parameter grid, materials, VB range,
and---crucially for the transfer design---whether each cutting edge carries a
multi-point wear *trajectory* (needed for the temporal model and few-shot) or
just isolated snapshots (as in small_subset). Reads material from
signals_stats.csv when present (no need to open the large .mat files).

Run:  python mutcm_inventory.py --dir ../data/mutcm_full/full_dataset
"""
import argparse
import csv
import re
from collections import defaultdict
from pathlib import Path

FNAME = re.compile(
    r"Insert(\d+)Edge(\d+)_Vc([\d.]+)_fz([\d.]+)_ap([\d.]+)_VB([\d.]+)_Rep(\w+?)\.mat$")


def find_sig_dir(base):
    base = Path(base)
    for cand in (base / "signals_synced", base, *base.glob("*/signals_synced")):
        if cand.is_dir() and any(cand.glob("*.mat")):
            return cand
    hits = list(base.rglob("*.mat"))
    if hits:
        return hits[0].parent
    raise SystemExit(f"no .mat files found under {base}")


def load_materials(base):
    for csvp in Path(base).rglob("signals_stats.csv"):
        rows = list(csv.reader(open(csvp, encoding="utf-8-sig"), delimiter=";"))
        h = rows[0]
        fn, mat = h.index("_file_name"), h.index("material")
        return {r[fn]: r[mat] for r in rows[1:] if len(r) > mat}
    return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="../data/mutcm_small/small_subset")
    args = ap.parse_args()
    sig = find_sig_dir(args.dir)
    materials = load_materials(args.dir)
    mats = sorted(sig.glob("*.mat"))
    print(f"signals dir: {sig}")
    print(f"total .mat files: {len(mats)}\n")

    params, matset, vbs = set(), set(), []
    per_edge = defaultdict(list)          # (insert, edge) -> [VB...]
    unparsed = []
    for f in mats:
        m = FNAME.search(f.name)
        if not m:
            unparsed.append(f.name); continue
        ins, edge, vc, fz, ap, vb, rep = m.groups()
        params.add((float(vc), float(fz), float(ap)))
        vbs.append(float(vb))
        per_edge[(int(ins), int(edge))].append(float(vb))
        if f.name in materials:
            matset.add(materials[f.name])

    print(f"cutting-parameter grid (Vc, fz, ap): {len(params)} combo(s)")
    for p in sorted(params):
        n = sum(1 for f in mats if FNAME.search(f.name)
                and (float(FNAME.search(f.name).group(3)),
                     float(FNAME.search(f.name).group(4)),
                     float(FNAME.search(f.name).group(5))) == p)
        print(f"    Vc={p[0]:<7} fz={p[1]:<6} ap={p[2]:<5} -> {n} files")
    print(f"\nmaterials: {sorted(matset) or '(no signals_stats.csv; unknown)'}")
    if vbs:
        print(f"VB range: {min(vbs):.3f}-{max(vbs):.3f} mm "
              f"({min(vbs)*1000:.0f}-{max(vbs)*1000:.0f} um), {len(set(vbs))} distinct")

    traj = {k: sorted(v) for k, v in per_edge.items() if len(v) >= 3}
    print(f"\ncutting edges with a wear trajectory (>=3 VB points): {len(traj)}/{len(per_edge)}")
    for (ins, edge), vlist in sorted(traj.items())[:12]:
        print(f"    Insert{ins} Edge{edge}: {len(vlist)} pts  VB={['%.3f'%x for x in vlist]}")
    if len(traj) > 12:
        print(f"    ... (+{len(traj)-12} more)")
    if not traj:
        print("    -> none: isolated snapshots only (temporal model needs k=1; "
              "few-shot/E3-by-trajectory not supported by this subset)")
    if unparsed:
        print(f"\n[warn] {len(unparsed)} filenames did not match the expected pattern, e.g. {unparsed[:3]}")

    # transfer-design verdict
    print("\n--- verdict ---")
    print(f"E3 (unseen cutting parameters) feasible: {'YES' if len(params) >= 3 else 'NO -- only %d param combo(s)' % len(params)}")
    print(f"temporal/few-shot on MU-TCM feasible:   {'YES' if traj else 'NO -- no per-edge trajectories'}")


if __name__ == "__main__":
    main()
