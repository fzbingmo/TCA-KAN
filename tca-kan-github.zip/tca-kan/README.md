# TCA-KAN: Interpretable Tool Wear Prediction Under Variable Cutting Conditions

Code and result files accompanying the paper

> *Interpretable Tool Wear Prediction Under Variable Cutting Conditions Using
> Kolmogorov–Arnold Networks: A Cross-Dataset Study* (submitted to **Machines**, MDPI).

TCA-KAN is a temporal-context attention Kolmogorov–Arnold network for flank wear
regression: 60 physically meaningful force/vibration features per cut are filtered by a
depthwise temporal convolution over the last *k* cuts, re-weighted by a
squeeze-and-excitation style attention gate, and mapped to flank wear through learnable
B-spline edge functions. Every input keeps an explicit univariate response curve, so the
learned feature–wear relationships can be audited against cutting physics
(monotonicity fraction *M_i*, cross-dataset agreement *A_i*).

## Repository layout

```
src/                 model, feature extraction, and data loading
  kan.py             KAN regressor (B-spline edges, activation_curves, sparsity_stats)
  model_proposed.py  TCA-KAN (depthwise temporal conv + SE gate + KAN head)
  baselines.py       MLP / SVR / GBDT / CNN-BiLSTM / DResNet-1d / PSD-CVT
  features.py        60-dim time + spectral feature extraction (10 features x 6 channels)
  data.py            PHM2010 and MU-TCM loaders (incl. missing-channel screening)
run_experiments.py   E1: leave-one-tool CV on PHM2010 (all models)
run_mutcm_cv.py      E2: leave-one-cutting-condition-out on MU-TCM
run_transfer.py      E3: bidirectional cross-dataset transfer (zero-/few-shot,
                     per-domain feature normalization)
run_ablation.py      19-variant ablation (per-variant RNG reseeding)
run_reg_sweep.py     L1-entropy regularization sweep (sparsity metrics)
run_noise.py         Noise robustness: AWGN at prescribed SNR, features re-extracted
efficiency_bench.py  Parameter count + single-thread CPU latency
compute_ai.py        Cross-dataset spline agreement A_i (Eq. 14 of the paper)
kan_compile.py       Lossless compilation of frozen splines to piecewise cubics
stats_tests.py       Wilcoxon signed-rank + paired Cohen's d
ablation_stats.py / reg_stats.py / aggregate_results.py   result aggregation
make_figures.py / fig1_schematic.py                       manuscript figures
smoke_test.py        synthetic-data smoke test (no datasets required)
results/             raw result JSONs backing the tables and figures of the paper
  full_raw/          E1, 3 folds x 10 seeds
  ablation_v2/       ablation, 3 folds x 10 seeds (corrected per-variant seeding)
  reg_sweep/         regularization sweep (sparsity metrics)
  noise/             noise robustness, 3 folds x 10 seeds
  mutcm_cv/          MU-TCM leave-one-condition-out summary
  fig_dump/          per-curve dumps used to render the prediction/spline figures
```

## Environment

Python ≥ 3.8. Install dependencies with

```bash
pip install -r requirements.txt
```

CPU is sufficient for the feature-driven models (full TCA-KAN training takes ~19 s per
fold on one core); the end-to-end baselines benefit from a GPU.

## Data

Neither dataset is redistributed here; both are public:

- **PHM2010** — 2010 PHM Society Conference Data Challenge (high-speed milling,
  tools c1/c4/c6 with per-cut flank wear labels, force + vibration at 50 kHz).
  https://phmsociety.org/phm_competition/2010-phm-society-conference-data-challenge/
- **MU-TCM** — Mondragon Unibertsitatea face-milling dataset,
  DOI [10.48764/3hdp-gf23](https://doi.org/10.48764/3hdp-gf23). Four of the 67 passes
  lack the external force/vibration channels and are excluded automatically by
  `src/data.py` (N = 63); the exclusion is screened from the .mat headers and is
  reproducible.

Point the scripts at the raw data directories via their CLI flags (see
`python run_experiments.py --help` and the headers of each script).

## Reproducing the paper

| Paper item | Command |
|---|---|
| Table E1 (within-dataset) | `python run_experiments.py --data-dir <phm2010> --seeds 10` |
| Ablation table | `python run_ablation.py --data-dir <phm2010> --seeds 10` |
| Regularization/sparsity | `python run_reg_sweep.py --data-dir <phm2010>` |
| MU-TCM leave-one-condition-out | `python run_mutcm_cv.py --mutcm-dir <mutcm>` |
| Cross-dataset transfer | `python run_transfer.py --phm-dir <phm2010> --mutcm-dir <mutcm> --reverse` |
| Noise robustness figure | `python run_noise.py --data-dir <phm2010>` |
| Efficiency table | `python efficiency_bench.py` |
| Spline agreement A_i | `python compute_ai.py --mutcm-dir <mutcm>` |
| Statistics (Wilcoxon, Cohen's d) | `python stats_tests.py results/full_raw` |
| Figures | `python make_figures.py --final` and `python fig1_schematic.py` |

Each experiment script fixes fold/seed enumeration internally; reported paper values are
mean ± 95% CI over the enumerated runs. The included `results/` JSONs are the exact runs
behind the submitted tables and figures.

## Citation

A `CITATION.cff` is provided; the full reference will be updated upon publication.

## License

MIT — see [LICENSE](LICENSE).
