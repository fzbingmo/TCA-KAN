"""Aggregate the corrected ablation rerun (results/ablation_v2) into TAB-8.

Every (fold, seed) JSON holds all 19 variants, so the full model is available
in-file for exact within-(fold,seed) pairing. We therefore report, per variant:
  * pooled RMSE mean +/- 95% CI (t) over the 3 folds x 10 seeds = 30 runs;
  * the paired delta vs the full model (RMSE_variant - RMSE_full), positive
    meaning the variant is worse, with its own 95% CI;
  * per-fold consistency -- in how many of the 3 folds the mean delta keeps the
    expected sign, plus the fraction of the 30 paired runs that move that way.

Following the agreed reporting scheme we lead with mean +/- CI and per-fold
consistency and drop the naked pooled Wilcoxon p, which is dominated by the
c1/c4/c6 baseline spread rather than the component effect. The pooled p is still
printed in parentheses for the record, never as the headline.

Run:  python ablation_stats.py [--dir results/ablation_v2]
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

FULL = "comp/full"
FOLDS = ("c1", "c4", "c6")


def ci95(vals):
    v = np.asarray(vals, dtype=float)
    if len(v) < 2:
        return v.mean(), 0.0
    half = stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return v.mean(), half


def load(d):
    """(fold, seed) -> variant -> rmse_um.  Also returns the ordered key list."""
    per = defaultdict(dict)
    for f in sorted(Path(d).glob("ablation_*.json")):
        r = json.loads(f.read_text())
        key = (r["fold"], r["seed"])
        for tag, v in r["variants"].items():
            per[key][tag] = v["rmse"] * 1e3
    return per, sorted(per)


def paired(per, keys, tag):
    """Return (variant rmse array, full rmse array) aligned over keys."""
    var = np.array([per[k][tag] for k in keys])
    full = np.array([per[k][FULL] for k in keys])
    return var, full


def per_fold_delta(per, keys, tag):
    """Mean delta (variant - full) within each fold, over that fold's seeds."""
    out = {}
    for fold in FOLDS:
        ds = [per[k][tag] - per[k][FULL] for k in keys if k[0] == fold]
        out[fold] = float(np.mean(ds)) if ds else float("nan")
    return out


def summarize(per, keys, tag):
    var, full = paired(per, keys, tag)
    diff = var - full                              # + => variant worse than full
    rm, rh = ci95(var)
    dm, dh = ci95(diff)
    pf = per_fold_delta(per, keys, tag)
    folds_worse = sum(1 for f in FOLDS if pf[f] > 0)
    runs_worse = int(np.sum(diff > 0))
    if np.allclose(diff, 0):                       # tag == full (or a duplicate of it)
        p = float("nan")
    else:
        try:
            _, p = stats.wilcoxon(var, full)
        except ValueError:
            p = float("nan")
    return dict(rmse=rm, rmse_ci=rh, d=dm, d_ci=dh, per_fold=pf,
               folds_worse=folds_worse, runs_worse=runs_worse, n=len(keys), p=p)


def line(tag, s, label=None):
    name = label or tag
    pf = s["per_fold"]
    return (f"  {name:<18}{s['rmse']:5.1f} ± {s['rmse_ci']:<4.1f}"
            f"  Δ={s['d']:+5.1f} ± {s['d_ci']:<4.1f}"
            f"  fold Δ [c1 {pf['c1']:+4.1f}  c4 {pf['c4']:+4.1f}  c6 {pf['c6']:+4.1f}]"
            f"  worse {s['folds_worse']}/3 folds, {s['runs_worse']}/{s['n']} runs"
            f"  (p={s['p']:.1e})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="results/ablation_v2")
    ap.add_argument("--e1-full", type=float, default=16.6,
                    help="E1 pooled full-model RMSE (um) for the sanity cross-check")
    args = ap.parse_args()

    per, keys = load(args.dir)
    if not keys:
        raise SystemExit(f"no ablation json in {args.dir}")
    n_folds = len({k[0] for k in keys})
    n_seeds = len({k[1] for k in keys})
    print(f"{len(keys)} runs = {n_folds} folds x {n_seeds} seeds from {args.dir}\n")

    # --- sanity: the RNG fix means comp/full == k/5 == G/5 == reg/on exactly ---
    dupes = ["k/5", "G/5", "reg/on"]
    maxdev = max(abs(per[k][FULL] - per[k][d]) for k in keys for d in dupes)
    fm, fh = ci95([per[k][FULL] for k in keys])
    print(f"[sanity] comp/full pooled RMSE = {fm:.1f} ± {fh:.1f} um "
          f"(E1 reports {args.e1_full}); duplicate-config max deviation = {maxdev:.2e} um "
          f"({'OK: reseed verified' if maxdev < 1e-6 else 'WARNING: configs diverge'})\n")

    blocks = [
        ("Component ablation (k=5, G=5, reg on)",
         [("comp/no_dtc", "-- DTC (gate kept)"), ("comp/no_gate", "-- gate (DTC kept)"),
          ("comp/plain_kan", "-- both (plain KAN)"), ("comp/mlp_head", "KAN head -> MLP")]),
        ("Context length k (G=5, reg on)",
         [("k/1", "k=1"), ("k/3", "k=3"), ("k/5", "k=5 (=full)"), ("k/9", "k=9")]),
        ("Grid size G (k=5, reg on)",
         [("G/3", "G=3"), ("G/5", "G=5 (=full)"), ("G/8", "G=8"), ("G/12", "G=12")]),
        ("Regularization (k=5, G=5)",
         [("reg/on", "reg on (=full)"), ("reg/off", "reg off")]),
        ("Feature-group removal (keep only one group)",
         [("feat/force_only", "force only"), ("feat/vibration_only", "vibration only"),
          ("feat/time_only", "time only"), ("feat/freq_only", "freq only")]),
    ]

    fs = summarize(per, keys, FULL)
    print(f"reference  full            {fs['rmse']:5.1f} ± {fs['rmse_ci']:<4.1f} um\n")
    summ = {FULL: fs}
    for title, rows in blocks:
        print(title)
        for tag, label in rows:
            s = summarize(per, keys, tag)
            summ[tag] = s
            print(line(tag, s, label))
        print()

    # --- LaTeX rows for TAB-8 ---
    print("=" * 72)
    print("LaTeX rows for TAB-8 (RMSE um; Delta vs full; folds worse):\n")

    def tex(tag, label, show_delta=True):
        s = summ[tag]
        rmse = f"${s['rmse']:.1f} \\pm {s['rmse_ci']:.1f}$"
        if not show_delta:
            return f"{label} & {rmse} & -- & -- \\\\"
        delta = f"${s['d']:+.1f}$"
        cons = f"{s['folds_worse']}/3"
        return f"{label} & {rmse} & {delta} & {cons} \\\\"

    print(tex(FULL, "Full TCA-KAN", show_delta=False))
    print("\\midrule\n\\multicolumn{4}{@{}l}{\\textit{Component removal}} \\\\")
    for tag, label in blocks[0][1]:
        print(tex(tag, label))
    print("\\midrule\n\\multicolumn{4}{@{}l}{\\textit{Context length $k$}} \\\\")
    for tag, label in blocks[1][1]:
        print(tex(tag, label, show_delta=(tag != "k/5")))
    print("\\midrule\n\\multicolumn{4}{@{}l}{\\textit{Grid size $G$}} \\\\")
    for tag, label in blocks[2][1]:
        print(tex(tag, label, show_delta=(tag != "G/5")))
    print("\\midrule\n\\multicolumn{4}{@{}l}{\\textit{Regularization}} \\\\")
    print(tex("reg/off", "$-$ L1--entropy reg"))
    print("\\midrule\n\\multicolumn{4}{@{}l}{\\textit{Feature-group removal}} \\\\")
    for tag, label in blocks[4][1]:
        print(tex(tag, label))


if __name__ == "__main__":
    main()
