"""Lossless compilation of a trained KAN to per-interval cubic polynomials.

After training, every edge activation phi(x) = sum_m b_m(x) * spline_weight_m is a
fixed piecewise-cubic function of the scalar input, so recomputing the B-spline
basis (de Boor recursion) at every forward pass is redundant. We precompute, for
each (out, in, knot-interval), the exact cubic coefficients of the frozen spline
(a cubic is determined by 4 points, and the spline is exactly cubic on each
interval, so the reconstruction is lossless to floating point) and fold the base
SiLU term in unchanged. Inference then reduces to a bucketize + gather + Horner
evaluation, replacing the recursion.

Use:
    cmodel = compile_tcakan(trained_tcakan)   # predictions bit-identical
    cmodel(x)                                 # same output, ~10x faster on CPU
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from src.kan import KANLinear, KANRegressor
from src.model_proposed import TCAKAN

_FRACS = torch.tensor([0.15, 0.38, 0.62, 0.85])   # 4 well-separated interior points


class CompiledKANLinear(nn.Module):
    """Drop-in replacement for a trained KANLinear using per-interval cubics."""

    def __init__(self, lin: KANLinear):
        super().__init__()
        self.in_features, self.out_features = lin.in_features, lin.out_features
        self.scale_base = lin.scale_base
        grid = lin.grid.detach()                      # (in, K)
        K = grid.shape[1]
        self.n_int = K - 1
        self.register_buffer("grid", grid.clone())
        self.register_buffer("base_weight", lin.base_weight.detach().clone())

        with torch.no_grad():
            W = lin.spline_weight.detach()            # (out, in, G+k)
            coeffs = torch.zeros(self.out_features, self.in_features, self.n_int, 4)
            for j in range(self.n_int):
                lo, hi = grid[:, j], grid[:, j + 1]                    # (in,)
                xs = lo[None, :] + _FRACS[:, None] * (hi - lo)[None, :]  # (4, in)
                basis = lin.b_splines(xs)                             # (4, in, G+k)
                s = torch.einsum("pik,oik->poi", basis, W)           # (4, out, in)
                # per-feature Vandermonde solve: V(in,4,4) c = rhs(in,4,out)
                xi = xs.T                                            # (in, 4)
                V = torch.stack([xi ** p for p in range(4)], dim=-1)  # (in, 4, 4)
                rhs = s.permute(2, 0, 1)                              # (in, 4, out)
                c = torch.linalg.solve(V, rhs)                       # (in, 4, out)
                coeffs[:, :, j, :] = c.permute(2, 0, 1)              # (out, in, 4)
        # flatten (in, interval) so a single index_select fetches the active cubic
        self.register_buffer("coeffs_flat",
                             coeffs.permute(1, 2, 0, 3).reshape(
                                 self.in_features * self.n_int, self.out_features, 4))
        self.register_buffer("row_base",
                             torch.arange(self.in_features) * self.n_int)
        self.register_buffer("lo", grid[:, 0].clone())
        self.register_buffer("hi", grid[:, -1].clone())

    def forward(self, x):                                            # (batch, in)
        b = x.shape[0]
        idx = (torch.searchsorted(self.grid, x.T.contiguous(), right=True) - 1)
        idx = idx.T.clamp(0, self.n_int - 1)                         # (batch, in)
        g = (self.row_base + idx).reshape(-1)                        # (batch*in,)
        csel = self.coeffs_flat.index_select(0, g).view(
            b, self.in_features, self.out_features, 4)               # (b, in, out, 4)
        inrange = ((x >= self.lo) & (x < self.hi)).to(x.dtype)       # (b, in)
        xp = torch.stack([inrange, x, x * x, x * x * x], dim=-1) \
            * inrange.unsqueeze(-1)                                  # (b, in, 4), zeroed OOR
        spline = torch.einsum("biop,bip->bo", csel, xp)             # (b, out)
        base = F.linear(F.silu(x), self.base_weight) * self.scale_base
        return base + spline


class CompiledKAN(nn.Module):
    def __init__(self, kan: KANRegressor):
        super().__init__()
        self.layers = nn.ModuleList(CompiledKANLinear(l) for l in kan.layers)

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x.squeeze(-1)


@torch.no_grad()
def compile_tcakan(model: TCAKAN):
    """Return a copy of the TCA-KAN whose KAN head is compiled to cubics."""
    import copy
    m = copy.deepcopy(model).eval()
    m.kan = CompiledKAN(model.kan).eval()
    return m


@torch.no_grad()
def compile_kan(kan: KANRegressor):
    return CompiledKAN(kan).eval()
