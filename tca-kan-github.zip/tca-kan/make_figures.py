"""Generate manuscript figures FIG-1/2/5 for the Machines draft.

Draft mode (default) trains on the local 25 Hz bundle and stamps a gray
draft note on data figures; --final drops the stamp for server-data reruns.
Run:  python make_figures.py [--data-dir DIR] [--out DIR] [--final]
"""
import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import torch
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from src.data import Standardizer, load_bundle
from src.kan import KANRegressor
from src.train import MLPRegressor, train_model

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
    "font.size": 7,
    "axes.spines.right": False,
    "axes.spines.top": False,
    "axes.linewidth": 0.8,
    "legend.frameon": False,
})

C_NEUTRAL = "#4D4D4D"   # measured / structure
C_SIGNAL = "#2166AC"    # proposed KAN
C_ACCENT = "#E08214"    # MLP baseline
C_KAN = "#1B7837"       # plain KAN (FIG-4 three-way comparison)
C_BOX = "#DEE7F0"       # schematic fill
C_DRAFT = "#B0B0B0"


def save_pub(fig, path_stem):
    fig.savefig(f"{path_stem}.pdf", bbox_inches="tight")
    fig.savefig(f"{path_stem}.svg", bbox_inches="tight")
    fig.savefig(f"{path_stem}.png", dpi=300, bbox_inches="tight")  # QA preview


def draft_stamp(fig, on):
    if on:
        fig.text(0.99, 0.01, "draft: 25 Hz bundle, regenerate with raw 50 kHz data",
                 ha="right", va="bottom", fontsize=5, color=C_DRAFT)


# ---------------------------------------------------------------- FIG-1
def fig1_framework(out, draft):
    fig, ax = plt.subplots(figsize=(6.7, 2.1))
    ax.set_xlim(0, 100); ax.set_ylim(0, 30); ax.axis("off")

    def box(x, y, w, h, label, fc=C_BOX):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6",
                                    fc=fc, ec=C_NEUTRAL, lw=0.8))
        ax.text(x + w / 2, y + h + 2.2, label, ha="center", va="bottom", fontsize=7)

    def arrow(x0, y0, x1, y1):
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
                                     mutation_scale=9, lw=0.9, color=C_NEUTRAL))

    # signals block: three mini waveforms
    box(1, 8, 12, 12, "Force / vibration\nsignals of cut $c$")
    rng = np.random.default_rng(3)
    t = np.linspace(0, 1, 120)
    for k in range(3):
        yy = 11 + 3.6 * k + 1.1 * np.sin(2 * np.pi * (4 + 2 * k) * t) * (0.6 + 0.4 * rng.random(120))
        ax.plot(2.2 + 9.6 * t, yy, lw=0.5, color=C_SIGNAL)

    # features block
    box(18, 8, 12, 12, "Feature extraction\n$\\psi:\\ 10 \\times 6$ channels")
    for r in range(4):
        for cidx in range(3):
            ax.plot(20.8 + cidx * 3.4, 10.5 + r * 2.2, "s", ms=2.2, color=C_SIGNAL, mec="none")

    # temporal context + attention block
    box(35, 8, 13, 12, "Temporal context\n+ attention gate")
    tk = np.linspace(0, 1, 30)
    for r, amp in enumerate([0.6, 1.0, 0.8]):
        ax.plot(36.5 + 4.5 * tk, 10.6 + r * 2.9 + amp * 1.1 * tk ** 2, lw=0.8, color=C_SIGNAL)
    for r, gval in enumerate([0.35, 0.9, 0.6]):
        ax.add_patch(FancyBboxPatch((43.5, 10.2 + r * 2.9), 3.2 * gval, 1.1,
                                    boxstyle="round,pad=0.1", fc=C_ACCENT, ec="none", alpha=0.8))
    ax.text(41.5, 8.9, "$k$ cuts $\\rightarrow$ DTC $\\rightarrow$ $g \\odot h$",
            ha="center", fontsize=5.5, color=C_NEUTRAL)

    # KAN block with edge splines
    box(53, 5, 20, 18, "KAN regressor\nedge splines $\\phi_{j,i}$")
    xin, xh, xo = 55.5, 63, 70.5
    yin = np.linspace(8, 20, 4); yh = np.linspace(9.5, 18.5, 3)
    for y0 in yin:
        ax.plot(xin, y0, "o", ms=2.6, color=C_NEUTRAL, mec="none")
    for y1 in yh:
        ax.plot(xh, y1, "o", ms=2.6, color=C_NEUTRAL, mec="none")
    ax.plot(xo, 14, "o", ms=2.6, color=C_NEUTRAL, mec="none")
    s = np.linspace(0, 1, 24)
    for y0 in yin:
        for y1 in yh:
            xs = xin + (xh - xin) * s
            ys = y0 + (y1 - y0) * s + 0.55 * np.sin(2 * np.pi * s)
            ax.plot(xs, ys, lw=0.45, color=C_SIGNAL, alpha=0.75)
    for y1 in yh:
        xs = xh + (xo - xh) * s
        ys = y1 + (14 - y1) * s + 0.55 * np.sin(2 * np.pi * s)
        ax.plot(xs, ys, lw=0.45, color=C_SIGNAL, alpha=0.75)

    # outputs
    box(79, 16, 19, 7, "Wear prediction $\\hat{V}_c$")
    ax.text(88.5, 19.2, "RMSE / MAE", ha="center", fontsize=6, color=C_NEUTRAL)
    box(79, 3, 19, 7, "Spline response curves")
    xs = np.linspace(0, 1, 40)
    ax.plot(81.5 + 6 * xs, 4.6 + 3.5 * (1 / (1 + np.exp(-6 * (xs - 0.5)))), lw=1.0, color=C_SIGNAL)
    ax.text(94, 6.4, "$M_i$, $A_i$", ha="center", va="center", fontsize=6, color=C_NEUTRAL)

    arrow(14.2, 14, 16.8, 14)
    arrow(31.2, 14, 33.8, 14)
    arrow(49.2, 14, 51.8, 14)
    arrow(74.2, 17, 77.8, 19.2)
    arrow(74.2, 11, 77.8, 6.8)
    fig.tight_layout()
    save_pub(fig, out / "fig1_framework")
    plt.close(fig)


# ---------------------------------------------------------------- shared training
def train_all(data_dir, epochs=300, seed=42):
    torch.manual_seed(seed); np.random.seed(seed)
    X, y, groups, names = load_bundle(data_dir, "phm2010")
    tr = np.isin(groups, ["c1", "c4"]); te = np.isin(groups, ["c6"])
    scaler = Standardizer().fit(X[tr], y[tr])
    X_tr, y_tr = scaler.transform(X[tr], y[tr])
    X_te = scaler.transform(X[te])
    kan = KANRegressor(X.shape[1], hidden=(32,), grid_size=5)
    mlp = MLPRegressor(X.shape[1])
    train_model(kan, X_tr, y_tr, epochs, log_every=10**9)
    train_model(mlp, X_tr, y_tr, epochs, log_every=10**9)
    with torch.no_grad():
        pred_kan = scaler.inverse_y(kan(torch.as_tensor(X_te)).numpy())
        pred_mlp = scaler.inverse_y(mlp(torch.as_tensor(X_te)).numpy())
    return kan, names, y[te], pred_kan, pred_mlp


# ---------------------------------------------------------------- FIG-2
def fig2_prediction(out, draft, y_te, pred_kan, pred_mlp):
    um = 1000.0
    idx = np.arange(1, len(y_te) + 1)
    rmse_k = np.sqrt(np.mean((pred_kan - y_te) ** 2)) * um
    rmse_m = np.sqrt(np.mean((pred_mlp - y_te) ** 2)) * um

    fig, ax = plt.subplots(figsize=(3.5, 2.4))
    ax.plot(idx, y_te * um, lw=1.2, color=C_NEUTRAL, label="Measured")
    ax.plot(idx, pred_kan * um, lw=0.9, color=C_SIGNAL,
            label=f"KAN (RMSE {rmse_k:.1f} $\\mu$m)")
    ax.plot(idx, pred_mlp * um, lw=0.9, color=C_ACCENT, alpha=0.85,
            label=f"MLP (RMSE {rmse_m:.1f} $\\mu$m)")
    ax.set_xlabel("Cut index (held-out tool c6)")
    ax.set_ylabel("Flank wear ($\\mu$m)")
    ax.legend(loc="lower right", fontsize=6)
    draft_stamp(fig, draft)
    fig.tight_layout()
    save_pub(fig, out / "fig2_prediction")
    plt.close(fig)


# ---------------------------------------------------------------- FIG-5
def fig5_splines(out, draft, kan, names):
    layer0 = kan.layers[0]
    w = layer0.spline_weight.detach().abs().mean(-1)        # (out, in)
    attribution = w.sum(0).numpy()                          # I_i, Eq. (11)
    top = np.argsort(attribution)[::-1][:6]

    fig, axes = plt.subplots(2, 3, figsize=(6.7, 3.6))
    for ax, i in zip(axes.ravel(), top):
        j_star = int(w[:, i].argmax())
        xs, ys = layer0.activation_curves(int(i), out_idx=j_star)
        dy = np.diff(ys)
        mono = max(np.mean(dy >= 0), np.mean(dy <= 0))      # M_i, Eq. (12)
        ax.plot(xs, ys, lw=1.1, color=C_SIGNAL)
        ch, feat = names[i].split("__")
        ax.set_title(f"{ch.replace('_', ' ')} — {feat.replace('_', ' ')}", fontsize=7)
        ax.text(0.04, 0.92, f"$I_i$ rank {list(top).index(i)+1}\n$M_i$ = {mono:.2f}",
                transform=ax.transAxes, va="top", fontsize=6, color=C_NEUTRAL)
        ax.set_xlabel("Standardized feature value", fontsize=6)
        ax.set_ylabel("$r_i(x)$", fontsize=6)
        ax.tick_params(labelsize=6)
    draft_stamp(fig, draft)
    fig.tight_layout()
    save_pub(fig, out / "fig5_splines")
    plt.close(fig)


# ---------------------------------------------------------------- FIG-4
_NOISE_LEVELS = ["clean", "8dB", "4dB", "0dB", "-4dB"]
_NOISE_LABELS = ["Clean", "8 dB", "4 dB", "0 dB", "$-4$ dB"]
_NOISE_MODELS = [("TCA-KAN (proposed)", C_SIGNAL, "o"),
                 ("KAN (plain)", C_KAN, "s"),
                 ("MLP", C_ACCENT, "^")]


def fig4_noise(out, results_dir):
    """FIG-4 from results/noise/*.json (run_noise.py): RMSE vs. SNR, mean +/- 95%
    CI over 3 folds x 10 seeds, categorical x-axis (noise levels are discrete)."""
    import json
    from pathlib import Path as _P
    from scipy import stats as _stats

    per = {lv: {m: [] for m, _, _ in _NOISE_MODELS} for lv in _NOISE_LEVELS}
    files = sorted(_P(results_dir).glob("noise_*.json"))
    if not files:
        raise SystemExit(f"no noise json under {results_dir}")
    for f in files:
        r = json.loads(f.read_text())
        for lv in _NOISE_LEVELS:
            for m, _, _ in _NOISE_MODELS:
                per[lv][m].append(r["rmse"][lv][m] * 1.0)   # already um

    def ci95(vals):
        v = np.asarray(vals, dtype=float)
        half = _stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
        return v.mean(), half

    fig, ax = plt.subplots(figsize=(3.5, 2.6))
    x = np.arange(len(_NOISE_LEVELS))
    for m, color, marker in _NOISE_MODELS:
        means = np.array([ci95(per[lv][m])[0] for lv in _NOISE_LEVELS])
        halfs = np.array([ci95(per[lv][m])[1] for lv in _NOISE_LEVELS])
        ax.errorbar(x, means, yerr=halfs, color=color, marker=marker, ms=3.5,
                   lw=1.1, capsize=2, label=m.split(" (")[0])
    ax.axvline(0.5, color=C_DRAFT, lw=0.6, ls="--")
    ax.set_xticks(x); ax.set_xticklabels(_NOISE_LABELS, fontsize=6.5)
    ax.set_xlabel("Test-signal noise level (SNR)")
    ax.set_ylabel("RMSE ($\\mu$m)")
    ax.legend(loc="upper left", fontsize=6)
    fig.tight_layout()
    save_pub(fig, out / "fig4_noise")
    plt.close(fig)
    return per


def fig2_from_dump(out, pred_npz):
    """FIG-2 from dumped per-cut predictions (final version, no watermark)."""
    z = np.load(pred_npz, allow_pickle=True)
    um = 1000.0
    y_te = z["y_te"]; idx = np.arange(1, len(y_te) + 1)
    tca = z["TCA-KAN_(proposed)"]; mlp = z["MLP"]
    r_t = np.sqrt(np.mean((tca - y_te) ** 2)) * um
    r_m = np.sqrt(np.mean((mlp - y_te) ** 2)) * um
    fig, ax = plt.subplots(figsize=(3.5, 2.4))
    ax.plot(idx, y_te * um, lw=1.2, color=C_NEUTRAL, label="Measured")
    ax.plot(idx, tca * um, lw=0.9, color=C_SIGNAL, label=f"TCA-KAN (RMSE {r_t:.1f} $\\mu$m)")
    ax.plot(idx, mlp * um, lw=0.9, color=C_ACCENT, alpha=0.85, label=f"MLP (RMSE {r_m:.1f} $\\mu$m)")
    ax.set_xlabel("Cut index (held-out tool)"); ax.set_ylabel("Flank wear ($\\mu$m)")
    ax.legend(loc="lower right", fontsize=6)
    fig.tight_layout(); save_pub(fig, out / "fig2_prediction"); plt.close(fig)


def fig5_from_dump(out, spline_npz, overlay_npz=None):
    """FIG-5 from dumped spline curves (final version, no watermark). If an
    overlay npz (compute_ai.py) is given, the seed-averaged MU-TCM curve is
    drawn range-matched to the PHM curve and A_i annotated per panel."""
    z = np.load(spline_npz, allow_pickle=True)
    ov = np.load(overlay_npz, allow_pickle=True) if overlay_npz else None
    top = z["top"]; names = z["names"]
    fig, axes = plt.subplots(2, 3, figsize=(6.7, 3.6))
    for ax, i in zip(axes.ravel(), top):
        xs, ys = z[f"x_{i}"], z[f"y_{i}"]
        dy = np.diff(ys); mono = max(np.mean(dy >= 0), np.mean(dy <= 0))
        ax.plot(xs, ys, lw=1.1, color=C_SIGNAL, label="PHM2010")
        note = f"$M_i$ = {mono:.2f}"
        if ov is not None:
            my = ov[f"my_{i}"]
            lo, hi = my.min(), my.max()
            disp = (my - lo) / (hi - lo) * (ys.max() - ys.min()) + ys.min() \
                if hi > lo else np.full_like(my, ys.mean())
            ax.plot(ov[f"mx_{i}"], disp, lw=1.0, ls="--", color=C_ACCENT,
                    label="MU-TCM (range-matched)")
            note += f"\n$A_i$ = {float(ov[f'ai_{i}']):.2f}"
        ch, feat = str(names[i]).split("__")
        ax.set_title(f"{ch.replace('_', ' ')} — {feat.replace('_', ' ')}", fontsize=7)
        ax.text(0.04, 0.92, note, transform=ax.transAxes, va="top",
                fontsize=6, color=C_NEUTRAL)
        ax.set_xlabel("Standardized feature value", fontsize=6)
        ax.set_ylabel("$r_i(x)$", fontsize=6); ax.tick_params(labelsize=6)
    if ov is not None:
        axes[0, 0].legend(fontsize=5, loc="lower right")
    fig.tight_layout(); save_pub(fig, out / "fig5_splines"); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=r"..\data\uniwear-dataset\data")
    ap.add_argument("--out", default=r"..\paper\figures")
    ap.add_argument("--final", action="store_true")
    ap.add_argument("--pred-npz", default=None, help="dumped predictions for final FIG-2")
    ap.add_argument("--spline-npz", default=None, help="dumped spline curves for final FIG-5")
    ap.add_argument("--noise-dir", default=None, help="results/noise directory for FIG-4")
    ap.add_argument("--overlay-npz", default=None, help="compute_ai.py output for the FIG-5 MU-TCM overlay")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    draft = not args.final

    if args.noise_dir:
        fig4_noise(out, args.noise_dir)
        print(f"FIG-4 from {args.noise_dir}; figure written to {out.resolve()}")
        return

    fig1_framework(out, draft)
    if args.pred_npz and args.spline_npz:
        fig2_from_dump(out, args.pred_npz)
        fig5_from_dump(out, args.spline_npz, overlay_npz=args.overlay_npz)
        print(f"final FIG-2/5 from dumps; figures written to {out.resolve()}")
    else:
        kan, names, y_te, pred_kan, pred_mlp = train_all(args.data_dir)
        fig2_prediction(out, draft, y_te, pred_kan, pred_mlp)
        fig5_splines(out, draft, kan, names)
        print(f"draft FIG-2/5 from local bundle; figures written to {out.resolve()}")


if __name__ == "__main__":
    main()
