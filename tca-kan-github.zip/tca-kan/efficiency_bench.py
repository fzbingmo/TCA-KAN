"""TAB-9 efficiency: parameter count and single-thread CPU inference latency.

Latency is the deployment-relevant metric (per-cut prediction on a shop-floor
CPU), so we measure it directly rather than quoting FLOPs -- standard FLOP
counters do not capture the KAN B-spline evaluation and would misrepresent the
proposed model. Each model is timed at its native input, batch size 1, on a
single CPU thread. Also reports the proposed model's CPU training time for the
retraining-feasibility claim.

Run:  python efficiency_bench.py [--reps 300]
"""
import argparse
import time

import numpy as np
import torch

from src.baselines import CNNBiLSTM, DResNet1d, PSDCVT
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor

D, C, L, NBINS = 60, 6, 256, 64      # features, raw channels, window length, PSD bins


def latency_ms(model, x, reps, warmup=25):
    model.eval()
    with torch.no_grad():
        for _ in range(warmup):
            model(x)
        t0 = time.perf_counter()
        for _ in range(reps):
            model(x)
        return (time.perf_counter() - t0) / reps * 1e3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=300)
    ap.add_argument("--train-time", action="store_true",
                    help="also measure TCA-KAN CPU training time on local features")
    args = ap.parse_args()
    torch.set_num_threads(1)
    torch.manual_seed(0)

    specs = [
        ("TCA-KAN (proposed)", TCAKAN(D, k=5, hidden=32, grid_size=5), torch.randn(1, 5, D)),
        ("KAN (plain)", KANRegressor(D, hidden=(32,), grid_size=5), torch.randn(1, D)),
        ("MLP", MLPRegressor(D), torch.randn(1, D)),
        ("CNN-BiLSTM", CNNBiLSTM(C), torch.randn(1, C, L)),
        ("DResNet-1d", DResNet1d(C), torch.randn(1, C, L)),
        ("PSD-CVT", PSDCVT(C), torch.randn(1, C, NBINS)),
    ]
    print(f"single-thread CPU, batch=1, {args.reps} reps "
          f"(raw window L={L}, PSD bins={NBINS})\n")
    print(f"{'Model':<22}{'Params':>10}{'Latency (ms)':>16}")
    rows = []
    for name, model, x in specs:
        p = sum(t.numel() for t in model.parameters())
        ms = latency_ms(model, x, args.reps)
        rows.append((name, p, ms))
        print(f"{name:<22}{p:>10,}{ms:>16.3f}")

    print("\nLaTeX rows (TAB-9):")
    for name, p, ms in rows:
        print(f"{name} & {p:,} & {ms:.2f} \\\\".replace(",", "{,}"))

    if args.train_time:
        from src.data import Standardizer, build_context, load_features
        from run_experiments import FOLDS, train_torch, val_split
        X, y, groups, _ = load_features(r"..\data\uniwear-dataset\data", "phm2010")
        tr_exps, te = FOLDS["c6"]
        tr, va = val_split(groups, tr_exps)
        sc = Standardizer().fit(X[tr], y[tr])
        Xc = (build_context(X, groups, k=5) - sc.x_mean) / sc.x_std
        ys = (y - sc.y_mean) / sc.y_std
        torch.manual_seed(0)
        model = TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5)
        t0 = time.perf_counter()
        train_torch(model, Xc[tr], ys[tr], Xc[va], ys[va], epochs=4000, device="cpu")
        print(f"\nTCA-KAN single-thread CPU training (fold c6, local features): "
              f"{time.perf_counter() - t0:.1f} s")


if __name__ == "__main__":
    main()
