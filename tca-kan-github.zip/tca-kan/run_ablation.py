"""Component and hyperparameter ablation of TCA-KAN for TAB-8.

Variants (each vs. the full model): remove DTC (single-cut input, gate kept),
remove attention gate (DTC kept), plain KAN (both removed), KAN head -> MLP head
(TCA front-end kept); context length k in {1,3,5,9}; grid size G in {3,5,8,12};
regularization on/off; feature-group removal.

Merged design notes:
  * device-aware training/prediction (reuses run_experiments helpers).
  * correct component semantics: no_dtc keeps the gate (GatedKAN); mlp_head
    keeps the temporal-context attention front-end (TCAMLP).
  * RNG independence: every variant reseeds immediately before model
    construction, so identical configurations (comp/full, k/5, G/5, reg/on)
    return identical RMSE and component deltas are interpretable.

Run:  python run_ablation.py --data-dir ../data/phm2010_raw --seeds 0 1 2 3 4 5 6 7 8 9 --epochs 4000
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from src.data import Standardizer, build_context, load_features
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor
from run_experiments import (FOLDS, metrics, predict_torch, resolve_device,
                             train_torch, val_split)

FEATURE_GROUPS = {
    "force_only": lambda n: [i for i, x in enumerate(n) if x.startswith("force")],
    "vibration_only": lambda n: [i for i, x in enumerate(n) if x.startswith("vibration")],
    "time_only": lambda n: [i for i, x in enumerate(n)
                            if x.split("__")[1] not in ("spec_centroid", "spec_energy")],
    "freq_only": lambda n: [i for i, x in enumerate(n)
                            if x.split("__")[1] in ("spec_centroid", "spec_energy")],
}


class TCAKAN_NoGate(TCAKAN):
    """DTC kept, attention gate removed."""

    def forward(self, x):
        h = self.dtc(x.permute(0, 2, 1)).squeeze(-1)
        return self.kan(h)


class GatedKAN(nn.Module):
    """Single-cut KAN with the attention gate retained; DTC/context removed."""

    def __init__(self, d, hidden=32, grid_size=5, reduction=4):
        super().__init__()
        bottleneck = max(1, d // reduction)
        self.gate = nn.Sequential(
            nn.Linear(d, bottleneck), nn.ReLU(),
            nn.Linear(bottleneck, d), nn.Sigmoid(),
        )
        self.kan = KANRegressor(d, hidden=(hidden,), grid_size=grid_size)

    def forward(self, x):
        return self.kan(x * self.gate(x))

    def regularization_loss(self):
        return self.kan.regularization_loss()


class TCAMLP(TCAKAN):
    """Full temporal-context attention front-end with the KAN head replaced by an MLP."""

    def __init__(self, d, k=5, hidden=32, grid_size=5):
        super().__init__(d, k=k, hidden=hidden, grid_size=grid_size)
        self.kan = MLPRegressor(d, hidden=(hidden,))

    def regularization_loss(self):
        return torch.zeros((), device=next(self.parameters()).device)


def build_variant(tag, d, k, grid, reg_on):
    """Return (model_factory, needs_context, reg_scale). The factory defers
    construction so run_one can reset the RNG immediately before init."""
    reg = 1e-5 if reg_on else 0.0
    if tag == "full":
        return (lambda: TCAKAN(d, k=k, hidden=32, grid_size=grid)), True, reg
    if tag == "no_dtc":                          # gate kept, DTC removed
        return (lambda: GatedKAN(d, hidden=32, grid_size=grid)), False, reg
    if tag == "no_gate":                         # DTC kept, gate removed
        return (lambda: TCAKAN_NoGate(d, k=k, hidden=32, grid_size=grid)), True, reg
    if tag == "plain_kan":                       # both removed
        return (lambda: KANRegressor(d, hidden=(32,), grid_size=grid)), False, reg
    if tag == "mlp_head":                        # TCA front-end kept, head replaced
        return (lambda: TCAMLP(d, k=k, hidden=32, grid_size=grid)), True, 0.0
    raise ValueError(tag)


def run_one(factory, needs_ctx, reg, Xs, Xcs, ys, y, tr, va, te, sc, epochs, device, seed):
    # Reseed right before construction so every variant starts from an identical,
    # reproducible init under the same seed; without this, variants sharing one
    # RNG stream get non-comparable inits (identical configs would diverge).
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = factory()
    Z = Xcs if needs_ctx else Xs
    model, stopped = train_torch(model, Z[tr], ys[tr], Z[va], ys[va], epochs,
                                 reg=reg, device=device)
    pred = predict_torch(model, Z[te], sc, device)
    return {**metrics(pred, y[te]), "stopped_epoch": stopped,
            "params": sum(p.numel() for p in model.parameters())}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=r"..\data\uniwear-dataset\data")
    ap.add_argument("--dataset", default="phm2010")
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--win-len", type=int, default=2048)  # unused; kept for CLI parity
    ap.add_argument("--out", default="results/ablation")
    ap.add_argument("--device", default="auto",
                    help="auto, cpu, cuda, or a concrete torch device such as cuda:0")
    ap.add_argument("--skip-existing", action="store_true",
                    help="resume by skipping output JSON files that already exist")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    device = resolve_device(args.device)
    print(f"device={device}")

    for fold in args.folds:
        train_exps, test_exps = FOLDS[fold]
        for seed in args.seeds:
            path = out / f"ablation_{fold}_seed{seed}.json"
            if args.skip_existing and path.exists():
                print(f"skip existing -> {path}")
                continue
            torch.manual_seed(seed); np.random.seed(seed)
            X, y, groups, names = load_features(args.data_dir, args.dataset)
            d = X.shape[1]
            tr, va = val_split(groups, train_exps)
            te = np.where(np.isin(groups, test_exps))[0]
            sc = Standardizer().fit(X[tr], y[tr])
            Xs = sc.transform(X); ys = (y - sc.y_mean) / sc.y_std
            res = {"fold": fold, "seed": seed, "variants": {}}

            # component ablation (k=5, G=5, reg on)
            Xcs = (build_context(X, groups, k=5) - sc.x_mean) / sc.x_std
            for tag in ["full", "no_dtc", "no_gate", "plain_kan", "mlp_head"]:
                fac, ctx, reg = build_variant(tag, d, 5, 5, True)
                res["variants"][f"comp/{tag}"] = run_one(
                    fac, ctx, reg, Xs, Xcs, ys, y, tr, va, te, sc, args.epochs, device, seed)

            # context length k
            for k in [1, 3, 5, 9]:
                Xck = (build_context(X, groups, k=k) - sc.x_mean) / sc.x_std
                res["variants"][f"k/{k}"] = run_one(
                    lambda kk=k: TCAKAN(d, k=kk, hidden=32, grid_size=5), True, 1e-5,
                    Xs, Xck, ys, y, tr, va, te, sc, args.epochs, device, seed)

            # grid size G
            for G in [3, 5, 8, 12]:
                res["variants"][f"G/{G}"] = run_one(
                    lambda GG=G: TCAKAN(d, k=5, hidden=32, grid_size=GG), True, 1e-5,
                    Xs, Xcs, ys, y, tr, va, te, sc, args.epochs, device, seed)

            # regularization on/off
            for reg_on in [True, False]:
                res["variants"][f"reg/{'on' if reg_on else 'off'}"] = run_one(
                    lambda: TCAKAN(d, k=5, hidden=32, grid_size=5), True,
                    1e-5 if reg_on else 0.0, Xs, Xcs, ys, y, tr, va, te, sc,
                    args.epochs, device, seed)

            # feature-group removal (proposed model on the subset)
            for gname, sel in FEATURE_GROUPS.items():
                idx = sel(names)
                Xsub = X[:, idx]
                scg = Standardizer().fit(Xsub[tr], y[tr])
                Xsub_s = scg.transform(Xsub)
                Xcsub = (build_context(Xsub, groups, k=5) - scg.x_mean) / scg.x_std
                res["variants"][f"feat/{gname}"] = run_one(
                    lambda nidx=len(idx): TCAKAN(nidx, k=5, hidden=32, grid_size=5), True,
                    1e-5, Xsub_s, Xcsub, ys, y, tr, va, te, scg, args.epochs, device, seed)

            path.write_text(json.dumps(res, indent=2))
            print(f"saved -> {path}  (full={res['variants']['comp/full']['rmse']*1e3:.1f} um)")


if __name__ == "__main__":
    main()
