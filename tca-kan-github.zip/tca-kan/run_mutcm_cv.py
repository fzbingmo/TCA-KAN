"""E3 within-MU-TCM generalization to unseen cutting parameters (TAB-6).

Leave-one-cutting-condition-out cross-validation on MU-TCM: train on all passes
except those at one (Vc, fz, ap) combination, test on the held-out combination.
This measures how well the model extrapolates across the cutting-parameter grid,
the axis the paper's variable-condition claim rests on. Temporal context is built
per tool (Insert_Edge) so wear trajectories are never crossed; folds are held out
by cutting condition. Requires full_dataset: small_subset has a single condition
and the script will say so and exit.

Run (server):
  python run_mutcm_cv.py --mutcm-dir ../data/mutcm_full/full_dataset \
         --seeds 0 1 2 3 4 --epochs 4000 --out results/mutcm_cv
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from src.data import (Standardizer, build_context, load_mutcm_features,
                      mutcm_metadata)
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor
from run_experiments import metrics, predict_torch, resolve_device, train_torch


def model_specs(d):
    return {
        "TCA-KAN (proposed)": ("ctx", lambda: TCAKAN(d, k=5, hidden=32, grid_size=5)),
        "KAN (plain)": ("flat", lambda: KANRegressor(d, hidden=(32,), grid_size=5)),
        "MLP": ("flat", lambda: MLPRegressor(d)),
    }


def val_from(idx, frac=0.15):
    n = max(1, int(len(idx) * frac))
    return idx[:-n], idx[-n:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mutcm-dir", default="../data/mutcm_small/small_subset")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--out", default="results/mutcm_cv")
    ap.add_argument("--device", default="auto")
    args = ap.parse_args()
    device = resolve_device(args.device)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)

    X, y, _, names = load_mutcm_features(args.mutcm_dir)
    meta = mutcm_metadata(args.mutcm_dir)
    cond, tool = meta["condition"], meta["tool"]
    conditions = sorted(set(cond))
    print(f"MU-TCM: {X.shape}, {len(conditions)} cutting conditions, "
          f"{len(set(tool))} tool edges")
    if len(conditions) < 2:
        raise SystemExit("E3 needs >=2 cutting conditions; this subset has "
                         f"{len(conditions)} -> use full_dataset.")

    # context is built once over the whole set using per-tool trajectories
    Xc_all = build_context(X, tool, k=5)
    results = defaultdict(lambda: defaultdict(list))    # model -> condition -> [rmse_um]
    for held in conditions:
        te = np.where(cond == held)[0]
        trva = np.where(cond != held)[0]
        sc = Standardizer().fit(X[trva], y[trva])
        Xf = sc.transform(X); Xc = (Xc_all - sc.x_mean) / sc.x_std
        ys = (y - sc.y_mean) / sc.y_std
        tr, va = val_from(trva)
        for name, (kind, factory) in model_specs(X.shape[1]).items():
            Z = Xc if kind == "ctx" else Xf
            for seed in args.seeds:
                torch.manual_seed(seed); np.random.seed(seed)
                model = factory()
                model, _ = train_torch(model, Z[tr], ys[tr], Z[va], ys[va],
                                       args.epochs, device=device)
                pred = predict_torch(model, Z[te], sc, device)
                results[name][held].append(metrics(pred, y[te])["rmse"] * 1e3)
        print(f"  held-out {held}: n_test={len(te)}  "
              + "  ".join(f"{m}={np.mean(results[m][held]):.1f}" for m in results))

    summary = {m: {c: float(np.mean(v)) for c, v in cd.items()} for m, cd in results.items()}
    (out / "mutcm_cv_results.json").write_text(json.dumps(summary, indent=2))
    print("\npooled RMSE (um) across held-out conditions:")
    for m, cd in summary.items():
        vals = list(cd.values())
        print(f"  {m:<22} {np.mean(vals):6.1f}")
    print(f"\nsaved -> {out/'mutcm_cv_results.json'}")


if __name__ == "__main__":
    main()
