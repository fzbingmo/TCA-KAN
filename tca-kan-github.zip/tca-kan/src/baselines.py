"""Baseline models for the comparison study.

Feature-driven: SVR, GBDT (scikit-learn, same 60 features as the proposed method).
End-to-end (raw per-cut windows resampled to fixed length):
  CNN-BiLSTM   -- convolutional front-end + bidirectional LSTM
  DResNet-1d   -- 1D residual conv network (compact reproduction of the
                  published architecture family; verify against reported
                  numbers on raw 50 kHz data before quoting)
  PSD-CVT      -- Welch PSD input, conv stem + small transformer encoder
                  (compact reproduction; same caveat)
"""
import numpy as np
import torch
import torch.nn as nn
from scipy import signal as sps
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.svm import SVR


# ------------------------------------------------------------ sklearn models
def fit_predict_sklearn(name, X_tr, y_tr, X_te):
    model = {
        "SVR": SVR(C=10.0, gamma="scale", epsilon=0.01),
        "GBDT": GradientBoostingRegressor(n_estimators=400, max_depth=3,
                                          learning_rate=0.05, random_state=0),
    }[name]
    model.fit(X_tr, y_tr)
    return model.predict(X_te)


# ------------------------------------------------------------ CNN-BiLSTM
class CNNBiLSTM(nn.Module):
    def __init__(self, in_ch, hidden=64):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(in_ch, 32, 7, stride=2, padding=3), nn.ReLU(),
            nn.Conv1d(32, 64, 5, stride=2, padding=2), nn.ReLU(),
        )
        self.lstm = nn.LSTM(64, hidden, batch_first=True, bidirectional=True)
        self.head = nn.Linear(2 * hidden, 1)

    def forward(self, w):                      # w: (batch, C, L)
        h = self.conv(w).permute(0, 2, 1)      # (batch, L', 64)
        out, _ = self.lstm(h)
        return self.head(out[:, -1]).squeeze(-1)


# ------------------------------------------------------------ DResNet-1d
class _ResBlock(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(ch, ch, 3, padding=1), nn.BatchNorm1d(ch), nn.ReLU(),
            nn.Conv1d(ch, ch, 3, padding=1), nn.BatchNorm1d(ch),
        )
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(x + self.body(x))


class DResNet1d(nn.Module):
    def __init__(self, in_ch, width=64, blocks=3):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv1d(in_ch, width, 7, stride=2, padding=3),
                                  nn.BatchNorm1d(width), nn.ReLU())
        self.blocks = nn.Sequential(*[_ResBlock(width) for _ in range(blocks)])
        self.head = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(width, 1))

    def forward(self, w):
        return self.head(self.blocks(self.stem(w))).squeeze(-1)


# ------------------------------------------------------------ PSD-CVT (compact)
def welch_psd(W, fs, n_bins=64):
    """W: (N, C, L) raw windows -> (N, C, n_bins) log-PSD, fixed bin count."""
    N, C, L = W.shape
    nper = min(L, 128)
    out = np.zeros((N, C, n_bins), dtype=np.float32)
    for i in range(N):
        for c in range(C):
            f, p = sps.welch(W[i, c], fs=fs, nperseg=nper)
            out[i, c] = np.interp(np.linspace(f[0], f[-1], n_bins), f, p)
    return np.log10(out + 1e-12)


class PSDCVT(nn.Module):
    def __init__(self, in_ch, n_bins=64, d_model=64, heads=4, layers=2):
        super().__init__()
        self.stem = nn.Conv1d(in_ch, d_model, 5, padding=2)
        enc = nn.TransformerEncoderLayer(d_model, heads, dim_feedforward=128,
                                         batch_first=True, dropout=0.1)
        self.encoder = nn.TransformerEncoder(enc, layers)
        self.head = nn.Linear(d_model, 1)

    def forward(self, p):                       # p: (batch, C, n_bins)
        tok = self.stem(p).permute(0, 2, 1)     # (batch, n_bins, d_model)
        return self.head(self.encoder(tok).mean(1)).squeeze(-1)
