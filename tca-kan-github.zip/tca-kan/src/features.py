"""Per-cut statistical and spectral feature extraction from raw signal windows."""
import numpy as np
from scipy import stats

# Feature names double as figure labels in the interpretability analysis,
# so keep them physically meaningful.
TIME_FEATURES = ["mean", "std", "rms", "kurtosis", "skewness", "peak", "crest_factor", "p2p"]
FREQ_FEATURES = ["spec_centroid", "spec_energy"]


def time_domain_features(sig):
    sig = np.asarray(sig, dtype=np.float64)
    rms = np.sqrt(np.mean(sig ** 2))
    peak = np.max(np.abs(sig))
    return [
        np.mean(sig),
        np.std(sig),
        rms,
        stats.kurtosis(sig) if sig.size > 3 else 0.0,
        stats.skew(sig) if sig.size > 2 else 0.0,
        peak,
        peak / rms if rms > 1e-12 else 0.0,
        np.ptp(sig),
    ]


def freq_domain_features(sig, fs):
    sig = np.asarray(sig, dtype=np.float64)
    if sig.size < 8:
        return [0.0, 0.0]
    spec = np.abs(np.fft.rfft(sig - sig.mean()))
    freqs = np.fft.rfftfreq(sig.size, d=1.0 / fs)
    energy = np.sum(spec ** 2)
    centroid = np.sum(freqs * spec) / (np.sum(spec) + 1e-12)
    return [centroid, energy]


def extract_features(window, channels, fs):
    """window: DataFrame slice for one cut; returns 1D feature vector."""
    feats = []
    for ch in channels:
        sig = window[ch].to_numpy()
        feats.extend(time_domain_features(sig))
        feats.extend(freq_domain_features(sig, fs))
    return np.asarray(feats, dtype=np.float32)


def feature_names(channels):
    return [f"{ch}__{f}" for ch in channels for f in TIME_FEATURES + FREQ_FEATURES]
