"""Loaders for PHM2010/NUAA milling data.

Two data layouts are supported behind the `load_features` / `load_windows`
dispatchers:
  bundle -- uniwear downsampled CSV (local validation only)
  raw    -- Kaggle/IEEE-DataPort PHM2010 layout: c1/..c6/ directories with one
            headerless 7-column csv per cut (Fx,Fy,Fz,Vx,Vy,Vz,AE-RMS @ 50 kHz)
            and a c*_wear.csv label file (per-cut flank wear of 3 flutes, in um).
Raw feature/window extraction is cached to .npz inside the data directory.
"""
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .features import extract_features, feature_names

CHANNELS = ["force_x", "force_y", "force_z", "vibration_x", "vibration_y", "vibration_z"]
RAW_COLUMNS = CHANNELS + ["ae_rms"]
RAW_FS = 50000.0
BUNDLE_FS = {"phm2010": 25.0, "nuaa": 15.0}  # approx. sampling rate of the bundles
BUNDLE_FILES = {
    "phm2010": "phm2010_bundle_high_resolution.csv",
    "nuaa": "nuaa_orthogonal_bundle_high_resolution.csv",
}


def is_raw_layout(data_dir):
    return any((Path(data_dir) / e).is_dir() for e in ("c1", "c4", "c6"))


def sampling_rate(data_dir, dataset="phm2010"):
    return RAW_FS if is_raw_layout(data_dir) else BUNDLE_FS[dataset]


def _raw_exp_dir(data_dir, exp):
    d = Path(data_dir) / exp
    inner = d / exp                      # kaggle zips often nest c1/c1/*.csv
    return inner if inner.is_dir() else d


def _raw_wear_mm(exp_dir, exp):
    for base in (exp_dir, exp_dir.parent):
        hits = sorted(base.glob("*wear*.csv"))
        if hits:
            w = pd.read_csv(hits[0])
            cols = [c for c in w.columns if "flute" in str(c).lower()] or list(w.columns[1:4])
            return w[cols].to_numpy(dtype=float).max(axis=1) / 1000.0   # um -> mm
    raise FileNotFoundError(f"no *wear*.csv label file found for {exp}")


def _raw_cut_frames(data_dir, exp):
    """Yield (cut_index, DataFrame with RAW_COLUMNS) in chronological order."""
    d = _raw_exp_dir(data_dir, exp)
    files = [f for f in d.glob("*.csv") if "wear" not in f.name.lower()]
    files.sort(key=lambda f: int(re.findall(r"(\d+)", f.stem)[-1]))
    if not files:
        raise FileNotFoundError(f"no cut csv files under {d}")
    for i, f in enumerate(files):
        head = f.open().readline()
        header = 0 if any(ch.isalpha() for ch in head) else None
        df = pd.read_csv(f, header=header).iloc[:, :len(RAW_COLUMNS)]
        df.columns = RAW_COLUMNS
        yield i, df


def load_phm2010_raw_features(data_dir, experiments=("c1", "c4", "c6"), use_cache=True):
    cache = Path(data_dir) / "phm2010_features_cache.npz"
    if use_cache and cache.exists():
        z = np.load(cache, allow_pickle=True)
        return z["X"], z["y"], z["groups"], list(z["names"])
    X, y, groups = [], [], []
    for exp in experiments:
        wear = _raw_wear_mm(_raw_exp_dir(data_dir, exp), exp)
        for i, df in _raw_cut_frames(data_dir, exp):
            if i >= len(wear):
                break
            X.append(extract_features(df, CHANNELS, RAW_FS))
            y.append(float(wear[i]))
            groups.append(exp)
        print(f"  raw features: {exp} done ({len(wear)} cuts)")
    X = np.stack(X); y = np.asarray(y, dtype=np.float32); groups = np.asarray(groups)
    names = feature_names(CHANNELS)
    if use_cache:
        np.savez_compressed(cache, X=X, y=y, groups=groups, names=names)
    return X, y, groups, names


def load_phm2010_raw_windows(data_dir, experiments=("c1", "c4", "c6"),
                             length=2048, use_cache=True):
    cache = Path(data_dir) / f"phm2010_windows_{length}_cache.npz"
    if use_cache and cache.exists():
        z = np.load(cache, allow_pickle=True)
        return z["W"], z["y"], z["groups"], list(z["channels"])
    W, y, groups = [], [], []
    xi = np.linspace(0.0, 1.0, length)
    for exp in experiments:
        wear = _raw_wear_mm(_raw_exp_dir(data_dir, exp), exp)
        for i, df in _raw_cut_frames(data_dir, exp):
            if i >= len(wear):
                break
            xs = np.linspace(0.0, 1.0, len(df))
            W.append(np.stack([np.interp(xi, xs, df[c].to_numpy()) for c in CHANNELS]))
            y.append(float(wear[i]))
            groups.append(exp)
        print(f"  raw windows: {exp} done")
    W = np.asarray(W, dtype=np.float32); y = np.asarray(y, dtype=np.float32)
    groups = np.asarray(groups)
    if use_cache:
        np.savez_compressed(cache, W=W, y=y, groups=groups, channels=CHANNELS)
    return W, y, groups, CHANNELS


def load_features(data_dir, dataset="phm2010", **kw):
    if dataset == "phm2010" and is_raw_layout(data_dir):
        return load_phm2010_raw_features(data_dir)
    return load_bundle(data_dir, dataset, **kw)


def load_windows(data_dir, dataset="phm2010", length=256, **kw):
    if dataset == "phm2010" and is_raw_layout(data_dir):
        return load_phm2010_raw_windows(data_dir, length=length)
    return load_raw_windows(data_dir, dataset, length=length, **kw)


def load_bundle(data_dir, dataset="phm2010", experiments=None, min_rows=16):
    """Returns (X, y, groups, names): features per cut, wear labels, cutter tags."""
    path = Path(data_dir) / BUNDLE_FILES[dataset]
    df = pd.read_csv(path)
    if experiments:
        df = df[df["experiment_tag"].isin(experiments)]

    fs = BUNDLE_FS[dataset]
    channels = [c for c in CHANNELS if c in df.columns]
    X, y, groups = [], [], []
    # cut boundary = change of (experiment_tag, tool_wear)
    cut_id = (df["experiment_tag"].ne(df["experiment_tag"].shift())
              | df["tool_wear"].ne(df["tool_wear"].shift())).cumsum()
    for _, cut in df.groupby(cut_id):
        if len(cut) < min_rows:
            continue
        X.append(extract_features(cut, channels, fs))
        y.append(float(cut["tool_wear"].iloc[0]))
        groups.append(str(cut["experiment_tag"].iloc[0]))
    return np.stack(X), np.asarray(y, dtype=np.float32), np.asarray(groups), feature_names(channels)


#: MU-TCM .mat signal name -> our canonical channel name (force/vibration match
#: PHM2010 exactly; AE_RMS is loaded by PHM2010 but not featurized, so we skip it).
MUTCM_CHANNEL_MAP = {"Fx": "force_x", "Fy": "force_y", "Fz": "force_z",
                     "Ax": "vibration_x", "Ay": "vibration_y", "Az": "vibration_z"}


def _mutcm_sig_dir(data_dir, subdir):
    base = Path(data_dir)
    return base / subdir if (base / subdir).is_dir() else base


def _mutcm_valid_files(sig_dir):
    """Sorted (kept, skipped) .mat lists. A file is kept only if all six external
    force/vibration channels are present and non-empty. A few MU-TCM experiments
    lost the external DAQ acquisition -- those channels are absent from the .mat
    (and the authors' own signals_stats.csv has NaN for them), so they cannot be
    featurized on the shared PHM2010 schema and are excluded. whosmat reads only
    the file header, so this check is cheap and both loaders apply it identically,
    keeping features and metadata aligned row-for-row."""
    import scipy.io as sio
    keep, skip = [], []
    for f in sorted(Path(sig_dir).glob("*.mat")):
        try:
            present = {name for name, shape, _ in sio.whosmat(f)
                       if len(shape) and min(shape) > 0}
            ok = set(MUTCM_CHANNEL_MAP).issubset(present)
        except Exception:
            ok = False
        (keep if ok else skip).append(f)
    return keep, skip


def load_mutcm_features(data_dir, subdir="signals_synced", use_cache=True):
    """MU-TCM face-milling passes -> the SAME 60-feature schema as PHM2010.

    Each *.mat is one machining pass carrying full 50 kHz force/vibration series
    plus a scalar flank-wear label VB (mm). We map Fx/Fy/Fz/Ax/Ay/Az onto the
    canonical force/vibration channels and run the identical feature extractor at
    RAW_FS, so a PHM2010-trained model transfers without any feature-definition
    mismatch. groups tag the workpiece material (the cross-dataset shift of
    interest); y is VB in mm, matching PHM2010's internal unit (um/1000). Passes
    missing the external force/vibration channels are skipped and reported.
    """
    import scipy.io as sio

    base = Path(data_dir)
    sig_dir = _mutcm_sig_dir(data_dir, subdir)
    cache = base / f"mutcm_features_{subdir}_cache.npz"
    if use_cache and cache.exists():
        z = np.load(cache, allow_pickle=True)
        return z["X"], z["y"], z["groups"], list(z["names"])

    keep, skip = _mutcm_valid_files(sig_dir)
    if skip:
        print(f"  [mutcm] excluding {len(skip)} file(s) missing external channels: "
              + ", ".join(f.name for f in skip))
    X, y, groups = [], [], []
    for f in keep:
        m = sio.loadmat(f)
        df = pd.DataFrame({canon: np.asarray(m[raw]).ravel()
                           for raw, canon in MUTCM_CHANNEL_MAP.items()})
        X.append(extract_features(df, CHANNELS, RAW_FS))
        y.append(float(np.asarray(m["VB"]).ravel()[0]))          # mm, as PHM2010
        groups.append(str(np.asarray(m["WorkpieceMaterial"]).ravel()[0]).strip())
    if not X:
        raise FileNotFoundError(f"no usable .mat files under {sig_dir}")
    X = np.stack(X); y = np.asarray(y, dtype=np.float32); groups = np.asarray(groups)
    names = feature_names(CHANNELS)
    if not np.isfinite(X).all():
        raise ValueError("non-finite MU-TCM features after extraction "
                         "(a kept file has present-but-empty channels?)")
    print(f"  [mutcm] featurized {len(X)} passes x {len(names)} features "
          f"(VB {y.min()*1e3:.0f}-{y.max()*1e3:.0f} um)")
    if use_cache:
        np.savez_compressed(cache, X=X, y=y, groups=groups, names=names)
    return X, y, groups, names


#: parse the encoded MU-TCM filename -> cutting condition and tool identity.
_MUTCM_FNAME = re.compile(
    r"Insert(\d+)Edge(\d+)_Vc([\d.]+)_fz([\d.]+)_ap([\d.]+)_VB([\d.]+)_Rep(\w+?)\.mat$")


def mutcm_metadata(data_dir, subdir="signals_synced"):
    """Per-pass metadata in the SAME order and over the SAME kept files as
    load_mutcm_features (both filter through _mutcm_valid_files), so the arrays
    align row-for-row with its feature matrix. Returns a dict of arrays:
    condition ('Vc..._fz..._ap...'), tool ('InsertN_EdgeM'), vb, insert, edge."""
    sig = _mutcm_sig_dir(data_dir, subdir)
    keep, _ = _mutcm_valid_files(sig)
    cond, tool, vb, ins_, edg_ = [], [], [], [], []
    for f in keep:
        m = _MUTCM_FNAME.search(f.name)
        if not m:
            cond.append("unknown"); tool.append(f.stem); vb.append(np.nan)
            ins_.append(-1); edg_.append(-1); continue
        ins, edge, vc, fz, ap, v, _ = m.groups()
        cond.append(f"Vc{vc}_fz{fz}_ap{ap}")
        tool.append(f"Insert{ins}_Edge{edge}")
        vb.append(float(v)); ins_.append(int(ins)); edg_.append(int(edge))
    return {"condition": np.array(cond), "tool": np.array(tool),
            "vb": np.array(vb, dtype=float),
            "insert": np.array(ins_), "edge": np.array(edg_)}


def build_context(X, groups, k=5):
    """Stack the features of the last k cuts per sample -> (N, k, d), oldest first.
    Sequences never cross experiment boundaries; the start is edge-padded."""
    Xc = np.zeros((len(X), k, X.shape[1]), dtype=np.float32)
    for g in np.unique(groups):
        idx = np.where(groups == g)[0]  # cuts already in chronological order
        for j, t in enumerate(idx):
            for kk in range(k):
                Xc[t, kk] = X[idx[max(j - (k - 1 - kk), 0)]]
    return Xc


def load_raw_windows(data_dir, dataset="phm2010", experiments=None,
                     length=256, min_rows=16):
    """Per-cut raw windows resampled to fixed length -> (N, C, length), y, groups.
    Used by the end-to-end baselines; swap the reader for 50 kHz data on the server."""
    path = Path(data_dir) / BUNDLE_FILES[dataset]
    df = pd.read_csv(path)
    if experiments:
        df = df[df["experiment_tag"].isin(experiments)]
    channels = [c for c in CHANNELS if c in df.columns]
    W, y, groups = [], [], []
    cut_id = (df["experiment_tag"].ne(df["experiment_tag"].shift())
              | df["tool_wear"].ne(df["tool_wear"].shift())).cumsum()
    xi = np.linspace(0.0, 1.0, length)
    for _, cut in df.groupby(cut_id):
        if len(cut) < min_rows:
            continue
        xs = np.linspace(0.0, 1.0, len(cut))
        W.append(np.stack([np.interp(xi, xs, cut[c].to_numpy()) for c in channels]))
        y.append(float(cut["tool_wear"].iloc[0]))
        groups.append(str(cut["experiment_tag"].iloc[0]))
    return (np.asarray(W, dtype=np.float32), np.asarray(y, dtype=np.float32),
            np.asarray(groups), channels)


class Standardizer:
    """Feature/target scaling fit on train split only (no test leakage)."""

    def fit(self, X, y):
        self.x_mean, self.x_std = X.mean(0), X.std(0) + 1e-8
        self.y_mean, self.y_std = y.mean(), y.std() + 1e-8
        return self

    def transform(self, X, y=None):
        Xs = (X - self.x_mean) / self.x_std
        if y is None:
            return Xs
        return Xs, (y - self.y_mean) / self.y_std

    def inverse_y(self, y_scaled):
        return y_scaled * self.y_std + self.y_mean
