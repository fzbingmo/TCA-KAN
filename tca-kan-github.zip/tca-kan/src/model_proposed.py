"""Proposed method: TCA-KAN.

Temporal-Context Attention KAN = depthwise temporal convolution over the
feature sequence of the last k cuts (per-feature filtering keeps every
dimension a named physical feature), an SE-style attention gate that
re-weights features per sample, and the KAN regression head.
"""
import torch
import torch.nn as nn

from .kan import KANRegressor


class TCAKAN(nn.Module):
    def __init__(self, d, k=5, hidden=32, grid_size=5, reduction=4):
        super().__init__()
        self.k = k
        # depthwise temporal conv: groups=d keeps feature identity
        self.dtc = nn.Conv1d(d, d, kernel_size=k, groups=d)
        with torch.no_grad():
            # init as "take current cut": last tap 1, others 0 -> stable start
            w = torch.zeros(d, 1, k)
            w[:, 0, -1] = 1.0
            self.dtc.weight.copy_(w + 0.01 * torch.randn_like(w))
            self.dtc.bias.zero_()
        self.gate = nn.Sequential(
            nn.Linear(d, d // reduction), nn.ReLU(),
            nn.Linear(d // reduction, d), nn.Sigmoid(),
        )
        self.kan = KANRegressor(d, hidden=(hidden,), grid_size=grid_size)

    def forward(self, x):
        """x: (batch, k, d) feature sequence, oldest first."""
        h = self.dtc(x.permute(0, 2, 1)).squeeze(-1)   # (batch, d), per-feature filtered
        g = self.gate(h)                               # (batch, d) attention in (0,1)
        return self.kan(h * g)

    def regularization_loss(self):
        return self.kan.regularization_loss()

    @torch.no_grad()
    def sparsity_stats(self, rel_thresh=0.01):
        return self.kan.sparsity_stats(rel_thresh)

    @torch.no_grad()
    def attention_weights(self, x):
        h = self.dtc(x.permute(0, 2, 1)).squeeze(-1)
        return self.gate(h)                            # inspectable per-sample gates
