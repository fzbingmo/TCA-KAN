"""Train KAN (vs MLP baseline) for tool wear regression.

Local usage (CPU smoke run):
    python -m src.train --dataset phm2010 --train-exp c1 c4 --test-exp c6 --epochs 200

On the HPC server the same entry point is reused with --epochs 2000 and the
raw-signal loader once the full-rate datasets are downloaded (see DOWNLOAD.md).
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from .data import Standardizer, load_bundle
from .kan import KANRegressor


class MLPRegressor(nn.Module):
    def __init__(self, in_features, hidden=(64, 32)):
        super().__init__()
        dims = [in_features, *hidden]
        layers = []
        for i in range(len(dims) - 1):
            layers += [nn.Linear(dims[i], dims[i + 1]), nn.SiLU()]
        layers.append(nn.Linear(dims[-1], 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(-1)


def train_model(model, X_tr, y_tr, epochs, lr=1e-3, reg=1e-5, log_every=50):
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    X_tr, y_tr = torch.as_tensor(X_tr), torch.as_tensor(y_tr)
    for epoch in range(1, epochs + 1):
        opt.zero_grad()
        pred = model(X_tr)
        loss = loss_fn(pred, y_tr)
        if reg and hasattr(model, "regularization_loss"):
            loss = loss + reg * model.regularization_loss()
        loss.backward()
        opt.step()
        if epoch % log_every == 0 or epoch == 1:
            print(f"  epoch {epoch:4d}  train MSE {loss.item():.5f}")
    return model


@torch.no_grad()
def evaluate(model, X, y, scaler):
    pred = scaler.inverse_y(model(torch.as_tensor(X)).numpy())
    rmse = float(np.sqrt(np.mean((pred - y) ** 2)))
    mae = float(np.mean(np.abs(pred - y)))
    return {"rmse": rmse, "mae": mae}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data/uniwear-dataset/data")
    ap.add_argument("--dataset", default="phm2010", choices=["phm2010", "nuaa"])
    ap.add_argument("--train-exp", nargs="+", default=["c1", "c4"])
    ap.add_argument("--test-exp", nargs="+", default=["c6"])
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--hidden", type=int, nargs="+", default=[32])
    ap.add_argument("--grid-size", type=int, default=5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    X, y, groups, names = load_bundle(args.data_dir, args.dataset)
    tr = np.isin(groups, args.train_exp)
    te = np.isin(groups, args.test_exp)
    print(f"dataset={args.dataset}  features={X.shape[1]}  train cuts={tr.sum()}  test cuts={te.sum()}")

    scaler = Standardizer().fit(X[tr], y[tr])
    X_tr, y_tr = scaler.transform(X[tr], y[tr])
    X_te = scaler.transform(X[te])

    results = {"config": vars(args), "n_train": int(tr.sum()), "n_test": int(te.sum())}
    for name, model in [
        ("KAN", KANRegressor(X.shape[1], hidden=tuple(args.hidden), grid_size=args.grid_size)),
        ("MLP", MLPRegressor(X.shape[1])),
    ]:
        print(f"[{name}] params={sum(p.numel() for p in model.parameters())}")
        t0 = time.time()
        train_model(model, X_tr, y_tr, args.epochs)
        metrics = evaluate(model, X_te, y[te], scaler)
        metrics["train_seconds"] = round(time.time() - t0, 1)
        metrics["params"] = sum(p.numel() for p in model.parameters())
        results[name] = metrics
        print(f"[{name}] test RMSE={metrics['rmse']:.4f}  MAE={metrics['mae']:.4f}  ({metrics['train_seconds']}s)")

    out = Path(args.out)
    out.mkdir(exist_ok=True)
    tag = f"{args.dataset}_{'-'.join(args.train_exp)}_to_{'-'.join(args.test_exp)}"
    (out / f"{tag}.json").write_text(json.dumps(results, indent=2))
    print(f"saved -> {out / f'{tag}.json'}")


if __name__ == "__main__":
    main()
