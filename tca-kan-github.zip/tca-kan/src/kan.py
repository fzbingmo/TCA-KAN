"""Compact KAN (Kolmogorov-Arnold Network) implementation for regression.

B-spline based KANLinear layer in the style of efficient-kan, with an
added `activation_curves` helper used for interpretability analysis
(exporting the learned per-feature spline functions).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class KANLinear(nn.Module):
    def __init__(self, in_features, out_features, grid_size=5, spline_order=3,
                 scale_base=1.0, scale_spline=1.0, grid_range=(-1.5, 1.5)):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.grid_size = grid_size
        self.spline_order = spline_order

        h = (grid_range[1] - grid_range[0]) / grid_size
        grid = torch.arange(-spline_order, grid_size + spline_order + 1, dtype=torch.float32)
        grid = grid * h + grid_range[0]
        self.register_buffer("grid", grid.expand(in_features, -1).contiguous())

        self.base_weight = nn.Parameter(torch.empty(out_features, in_features))
        self.spline_weight = nn.Parameter(torch.empty(out_features, in_features, grid_size + spline_order))
        nn.init.kaiming_uniform_(self.base_weight, a=5 ** 0.5)
        nn.init.normal_(self.spline_weight, mean=0.0, std=0.1 * scale_spline / (grid_size + spline_order))
        self.scale_base = scale_base

    def b_splines(self, x):
        """x: (batch, in_features) -> (batch, in_features, grid_size + spline_order)"""
        grid = self.grid  # (in, G + 2k + 1)
        x = x.unsqueeze(-1)
        bases = ((x >= grid[:, :-1]) & (x < grid[:, 1:])).to(x.dtype)
        for k in range(1, self.spline_order + 1):
            left = (x - grid[:, : -(k + 1)]) / (grid[:, k:-1] - grid[:, : -(k + 1)]) * bases[..., :-1]
            right = (grid[:, k + 1:] - x) / (grid[:, k + 1:] - grid[:, 1:-k]) * bases[..., 1:]
            bases = left + right
        return bases

    def forward(self, x):
        base = F.linear(F.silu(x), self.base_weight) * self.scale_base
        spline = F.linear(
            self.b_splines(x).reshape(x.size(0), -1),
            self.spline_weight.reshape(self.out_features, -1),
        )
        return base + spline

    def regularization_loss(self, l1_scale=1.0, entropy_scale=1.0):
        w = self.spline_weight.abs().mean(-1)
        l1 = w.sum()
        p = w / (l1 + 1e-8)
        entropy = -(p * (p + 1e-8).log()).sum()
        return l1_scale * l1 + entropy_scale * entropy

    @torch.no_grad()
    def activation_curves(self, feature_idx, out_idx=0, n_points=200):
        """Evaluate the learned univariate function phi(x) for one input feature.

        Returns (xs, ys) suitable for plotting the spline learned between
        input `feature_idx` and output `out_idx` - the basis of the paper's
        interpretability analysis.
        """
        lo, hi = self.grid[feature_idx, self.spline_order], self.grid[feature_idx, -self.spline_order - 1]
        device = self.grid.device
        xs = torch.linspace(lo, hi, n_points, device=device)
        full = torch.zeros(n_points, self.in_features, device=device)
        full[:, feature_idx] = xs
        bases = self.b_splines(full)[:, feature_idx, :]                      # (n, G+k)
        ys_spline = bases @ self.spline_weight[out_idx, feature_idx, :]      # (n,)
        ys_base = F.silu(xs) * self.base_weight[out_idx, feature_idx] * self.scale_base
        return xs.cpu().numpy(), (ys_spline + ys_base).cpu().numpy()

    @torch.no_grad()
    def edge_magnitudes(self):
        """Per-edge spline importance |phi_ij| = mean_k |spline_weight|, shape
        (out, in). Same quantity the L1--entropy penalty acts on and that the
        interpretability attribution uses, so sparsity is measured consistently."""
        return self.spline_weight.abs().mean(-1)


class KANRegressor(nn.Module):
    """Stacked KANLinear layers ending in a single regression output."""

    def __init__(self, in_features, hidden=(32,), grid_size=5, spline_order=3):
        super().__init__()
        dims = [in_features, *hidden, 1]
        self.layers = nn.ModuleList(
            KANLinear(dims[i], dims[i + 1], grid_size=grid_size, spline_order=spline_order)
            for i in range(len(dims) - 1)
        )

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x.squeeze(-1)

    def regularization_loss(self):
        return sum(layer.regularization_loss() for layer in self.layers)

    @torch.no_grad()
    def sparsity_stats(self, rel_thresh=0.01):
        """Sparsity descriptors of the learned response, aggregated over all
        spline edges. Answers whether a stronger L1--entropy penalty concentrates
        the network onto fewer edges:
          l1        -- sum of per-edge magnitudes (the penalized quantity);
          entropy   -- entropy of the normalized edge distribution (lower = more
                       concentrated);
          eff_edges -- exp(entropy), the effective number of active edges;
          dead_frac -- fraction of edges below rel_thresh of the largest edge.
        """
        mags = torch.cat([layer.edge_magnitudes().flatten() for layer in self.layers])
        total = mags.sum()
        p = mags / (total + 1e-8)
        entropy = -(p * (p + 1e-8).log()).sum()
        dead = (mags < rel_thresh * mags.max()).float().mean()
        return {
            "n_edges": int(mags.numel()),
            "l1": float(total),
            "entropy": float(entropy),
            "eff_edges": float(entropy.exp()),
            "dead_frac": float(dead),
            "max_edge": float(mags.max()),
            "mean_edge": float(mags.mean()),
            "l1_per_layer": [float(layer.edge_magnitudes().sum()) for layer in self.layers],
        }
