"""Aggregate the regularization sweep (results/reg_sweep) for the sparsity story.

For each L1--entropy strength we pool the 3 folds x 10 seeds and report test RMSE
alongside the KAN head's sparsity descriptors (l1, effective active edges,
dead-edge fraction), all mean +/- 95% CI. Two questions drive the read:

  1. Is reg=1e-5 effectively no penalty for accuracy?  -> the paired reg=1e-5
     vs reg=0 delta (same init per seed) should be ~0 in RMSE while l1 already
     shrinks, i.e. a mild sparsifier with no accuracy cost.
  2. Does a stronger penalty sparsify, and at what accuracy?  -> the l1 /
     eff_edges / dead_frac trend across levels, with the per-fold RMSE so any
     accuracy change (e.g. on the hard c6 fold) is not hidden by pooling.

Run:  python reg_stats.py [--dir results/reg_sweep]
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

LEVELS = ["0", "1e-05", "0.0001", "0.001", "0.01"]
LABEL = {"0": "0 (off)", "1e-05": "1e-5", "0.0001": "1e-4", "0.001": "1e-3", "0.01": "1e-2"}
FOLDS = ("c1", "c4", "c6")


def ci95(vals):
    v = np.asarray(vals, dtype=float)
    if len(v) < 2:
        return v.mean(), 0.0
    half = stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return v.mean(), half


def load(d):
    """(fold, seed) -> reg_key -> record dict."""
    per = defaultdict(dict)
    for f in sorted(Path(d).glob("reg_*.json")):
        r = json.loads(f.read_text())
        per[(r["fold"], r["seed"])] = r["reg_sweep"]
    return per, sorted(per)


def col(per, keys, reg, field, scale=1.0):
    return np.array([per[k][reg][field] * scale for k in keys])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="results/reg_sweep")
    args = ap.parse_args()
    per, keys = load(args.dir)
    if not keys:
        raise SystemExit(f"no reg_sweep json in {args.dir}")
    n_folds = len({k[0] for k in keys}); n_seeds = len({k[1] for k in keys})
    print(f"{len(keys)} runs = {n_folds} folds x {n_seeds} seeds from {args.dir}\n")

    hdr = f"{'reg':<10}{'RMSE (um)':<16}{'l1':<15}{'eff_edges':<15}{'dead_frac':<12}"
    print(hdr)
    for reg in LEVELS:
        rm, rh = ci95(col(per, keys, reg, "rmse", 1e3))
        lm, lh = ci95(col(per, keys, reg, "l1"))
        em, eh = ci95(col(per, keys, reg, "eff_edges"))
        dm, dh = ci95(col(per, keys, reg, "dead_frac"))
        print(f"{LABEL[reg]:<10}{rm:5.1f} ± {rh:<8.1f}{lm:6.1f} ± {lh:<6.1f}"
              f"{em:6.0f} ± {eh:<6.0f}{dm:5.0%} ± {dh:<6.0%}")

    # --- Q1: reg=1e-5 vs reg=0, paired within (fold, seed) ---
    dr = col(per, keys, "1e-05", "rmse", 1e3) - col(per, keys, "0", "rmse", 1e3)
    dl = col(per, keys, "1e-05", "l1") - col(per, keys, "0", "l1")
    drm, drh = ci95(dr); dlm, dlh = ci95(dl)
    print(f"\n[Q1] reg=1e-5 vs reg=0 (paired): "
          f"ΔRMSE = {drm:+.2f} ± {drh:.2f} um, Δl1 = {dlm:+.1f} ± {dlh:.1f} "
          f"-> {'no accuracy cost, mild sparsifier' if abs(drm) < 0.5 else 'accuracy shift'}")

    # --- Q2: per-fold RMSE across levels (does strong reg help/hurt a fold?) ---
    print("\n[Q2] per-fold RMSE (um) across reg levels:")
    print(f"{'fold':<6}" + "".join(f"{LABEL[r]:>10}" for r in LEVELS))
    for fold in FOLDS:
        fk = [k for k in keys if k[0] == fold]
        row = "".join(f"{np.mean(col(per, fk, r, 'rmse', 1e3)):>10.1f}" for r in LEVELS)
        print(f"{fold:<6}{row}")

    # --- LaTeX rows (reg | RMSE | l1 | eff_edges | dead_frac) ---
    print("\nLaTeX rows (reg sweep):")
    for reg in LEVELS:
        rm, rh = ci95(col(per, keys, reg, "rmse", 1e3))
        lm, lh = ci95(col(per, keys, reg, "l1"))
        em, eh = ci95(col(per, keys, reg, "eff_edges"))
        dm, _ = ci95(col(per, keys, reg, "dead_frac"))
        print(f"${LABEL[reg]}$ & ${rm:.1f} \\pm {rh:.1f}$ & ${lm:.1f} \\pm {lh:.1f}$ "
              f"& ${em:.0f} \\pm {eh:.0f}$ & {dm:.0%} \\\\".replace("%", "\\%"))


if __name__ == "__main__":
    main()
