"""Paired significance tests: proposed TCA-KAN vs each baseline.

Pairs are matched by (fold, seed); 3 folds x 10 seeds = 30 paired observations.
Reports Wilcoxon signed-rank p and paired Cohen's d for RMSE, plus win rate.
Run:  python stats_tests.py --dir results/full_raw
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

PROPOSED = "TCA-KAN (proposed)"


def load_paired(d):
    per = defaultdict(dict)   # (fold,seed) -> model -> rmse_um
    for f in sorted(Path(d).glob("*.json")):
        r = json.loads(f.read_text())
        key = (r["fold"], r["seed"])
        for m, v in r["models"].items():
            per[key][m] = v["rmse"] * 1e3
    return per


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="results/full_raw")
    args = ap.parse_args()
    per = load_paired(args.dir)
    keys = sorted(per)
    models = [m for m in per[keys[0]] if m != PROPOSED]

    prop = np.array([per[k][PROPOSED] for k in keys])
    print(f"{len(keys)} paired observations (fold x seed)\n")
    print(f"{'Baseline':<22}{'mean diff (um)':<16}{'Wilcoxon p':<14}{'Cohen d':<10}{'win rate':<10}")
    latex = []
    for m in models:
        base = np.array([per[k][m] for k in keys])
        diff = base - prop                       # positive => proposed better
        try:
            _, p = stats.wilcoxon(prop, base)
        except ValueError:
            p = float("nan")
        d = diff.mean() / diff.std(ddof=1) if diff.std(ddof=1) > 0 else float("nan")
        win = float(np.mean(diff > 0))
        star = "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < 5e-2 else "n.s."
        print(f"{m:<22}{diff.mean():<16.2f}{p:<9.2e}{star:<5}{d:<10.2f}{win:<10.0%}")
        latex.append(f"{m} & {diff.mean():.1f} & {p:.1e} ({star}) & {d:.2f} \\\\")

    print("\nLaTeX (proposed-vs-baseline significance block):")
    for row in latex:
        print(row)


if __name__ == "__main__":
    main()
