"""R2: verify the first-layer spline curves against the complete TCA-KAN (reviewer 1,
comment 6) and compare the spline attribution with post-hoc attributions (reviewer 2,
comment 2).

For every dumped E1 model (results/e1_supp/models, produced by run_e1_supplement.py,
identical to the E1 runs) and its fold:
  * coverage   share of head inputs g_i h_i inside the spline-grid interior [-1.5, 1.5]
  * layer 2    monotonicity of the second-layer function phi2_{j*} over the range its
               input u_{j*} takes on the test cuts (orientation-free)
  * PD         partial dependence of the complete model on feature i (feature i set to x
               in every context slot of every test cut), compared with the first-layer
               curve composed with the mean head input, r_i(xbar_i(x)): Pearson rho and
               the orientation-free monotonicity of the PD curve
  * gate       mean gate value of the top features against all features
  * SHAP       expected-gradient SHAP of the complete model (shap.GradientExplainer),
               summed over the context window; Spearman correlation with I_i over all 60
               features and the overlap of the top-6 sets
  * TreeSHAP   the same comparison for the GBDT baseline refitted on the fold
Run (local):
  python interp_fullmodel.py --cache <phm2010 data>/phm2010_features_cache.npz \
         --models results/e1_supp/models --out results/interp
"""
import argparse
import json
from pathlib import Path

import numpy as np
import shap
import torch
import torch.nn.functional as F
from scipy import stats
from sklearn.ensemble import GradientBoostingRegressor

from src.data import build_context
from src.model_proposed import TCAKAN
from run_experiments import FOLDS, val_split

TOP = 6


def edge(layer, j, i, x):
    """phi_{j,i}(x) of one KANLinear edge for a 1-D tensor x."""
    full = torch.zeros(len(x), layer.in_features)
    full[:, i] = x
    bases = layer.b_splines(full)[:, i, :]
    return (bases @ layer.spline_weight[j, i, :]
            + F.silu(x) * layer.base_weight[j, i] * layer.scale_base)


def mono(y):
    dy = np.diff(y)
    return float(max(np.mean(dy >= 0), np.mean(dy <= 0)))


def head_input(model, xc):
    h = model.dtc(xc.permute(0, 2, 1)).squeeze(-1)
    return h * model.gate(h), model.gate(h)


@torch.no_grad()
def analyse(model, Xcs, te, tr, sc, n_grid=60):
    l0, l1 = model.kan.layers[0], model.kan.layers[1]
    w = l0.spline_weight.abs().mean(-1)                    # (32, 60)
    I = w.sum(0).numpy()
    top = np.argsort(I)[::-1][:TOP]
    xte = torch.as_tensor(Xcs[te], dtype=torch.float32)
    hin, gate = head_input(model, xte)
    u = l0(hin)                                            # (N, 32) second-layer inputs
    out = {"I": I.tolist(), "top": top.tolist(),
           "coverage_all": float((hin.abs() <= 1.5).float().mean()),
           "gate_mean_all": float(gate.mean()), "features": {}}
    for i in top:
        i = int(i)
        j = int(w[:, i].argmax())
        # layer-2 function over the observed range of its input
        us = torch.linspace(float(u[:, j].min()), float(u[:, j].max()), 200)
        phi2 = edge(l1, 0, j, us).numpy()
        # partial dependence over the observed range of the raw standardized feature
        zcur = Xcs[te][:, -1, i]
        zs = np.linspace(np.percentile(zcur, 1), np.percentile(zcur, 99), n_grid)
        pd_curve, xbar = [], []
        for zv in zs:
            xm = xte.clone()
            xm[:, :, i] = float(zv)
            hm, _ = head_input(model, xm)
            pd_curve.append(float(model(xm).mean()) * sc["y_std"] + sc["y_mean"])
            xbar.append(float(hm[:, i].mean()))
        pd_curve = np.array(pd_curve)
        r_comp = edge(l0, j, i, torch.as_tensor(np.array(xbar), dtype=torch.float32)).numpy()
        rho = float(np.corrcoef(pd_curve, r_comp)[0, 1]) if np.std(r_comp) > 0 else float("nan")
        xs_grid = torch.linspace(-1.5, 1.5, 200)
        out["features"][i] = {
            "j_star": j, "share_of_I_on_j_star": float(w[j, i] / w[:, i].sum()),
            "coverage": float((hin[:, i].abs() <= 1.5).float().mean()),
            "M_first_layer": mono(edge(l0, j, i, xs_grid).numpy()),
            "M_layer2": mono(phi2),
            "M_pd": mono(pd_curve), "rho_pd_vs_first_layer": rho,
            "gate_mean": float(gate[:, i].mean()),
            "pd_z": zs.tolist(), "pd_um": (pd_curve * 1e3).tolist(),
            "first_layer_composed": r_comp.tolist()}
    return out


def shap_compare(model, Xcs, te, tr, I, n_bg=100, seed=0):
    rng = np.random.default_rng(seed)
    bg = torch.as_tensor(Xcs[rng.choice(tr, size=min(n_bg, len(tr)), replace=False)],
                         dtype=torch.float32)
    class TwoD(torch.nn.Module):                          # SHAP expects (N, outputs)
        def __init__(self, m):
            super().__init__(); self.m = m

        def forward(self, x):
            return self.m(x).reshape(len(x), -1)

    expl = shap.GradientExplainer(TwoD(model), bg)
    np.random.seed(seed); torch.manual_seed(seed)          # expected-gradient sampling
    sv = expl.shap_values(torch.as_tensor(Xcs[te], dtype=torch.float32))
    sv = np.asarray(sv).reshape(len(te), Xcs.shape[1], Xcs.shape[2])
    glob = np.abs(sv.sum(1)).mean(0)                      # sum over the context window
    return glob


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", required=True)
    ap.add_argument("--models", required=True)
    ap.add_argument("--folds", nargs="+", default=["c1", "c4", "c6"])
    ap.add_argument("--seeds", type=int, nargs="+", default=list(range(10)))
    ap.add_argument("--no-shap", action="store_true")
    ap.add_argument("--out", default="results/interp")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    z = np.load(args.cache, allow_pickle=True)
    X, y, groups, names = z["X"], z["y"], z["groups"], list(z["names"])
    Xc = build_context(X, groups, k=5)
    gbdt_cache = {}
    for fold in args.folds:
        for seed in args.seeds:
            mp = Path(args.models) / f"{fold}_seed{seed}_TCAKAN.pt"
            if not mp.exists():
                continue
            scz = np.load(Path(args.models) / f"{fold}_seed{seed}_scaler.npz")
            sc = {k: scz[k] for k in scz.files}
            Xcs = (Xc - sc["x_mean"]) / sc["x_std"]
            tr, va = val_split(groups, FOLDS[fold][0])
            te = sc["te_idx"]
            model = TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5)
            model.load_state_dict(torch.load(mp, map_location="cpu"))
            model.eval()
            res = analyse(model, Xcs, te, tr, sc)
            res.update({"fold": fold, "seed": seed, "names": names})
            I = np.array(res["I"])
            top_I = set(np.argsort(I)[::-1][:TOP])
            if not args.no_shap:
                g = shap_compare(model, Xcs, te, tr, I, seed=seed)
                res["shap_global"] = g.tolist()
                res["spearman_shap_vs_I"] = float(stats.spearmanr(g, I)[0])
                res["top6_overlap_shap"] = len(top_I & set(np.argsort(g)[::-1][:TOP]))
            if fold not in gbdt_cache:                     # GBDT is seed-independent
                Xs = (X - sc["x_mean"]) / sc["x_std"]
                ys = (y - sc["y_mean"]) / sc["y_std"]
                fit = np.concatenate([tr, va])
                gb = GradientBoostingRegressor(n_estimators=400, max_depth=3,
                                               learning_rate=0.05, random_state=0)
                gb.fit(Xs[fit], ys[fit])
                tv = shap.TreeExplainer(gb).shap_values(Xs[te])
                gbdt_cache[fold] = np.abs(tv).mean(0)
            res["spearman_treeshap_gbdt_vs_I"] = float(stats.spearmanr(gbdt_cache[fold], I)[0])
            res["top6_overlap_treeshap_gbdt"] = len(top_I & set(np.argsort(gbdt_cache[fold])[::-1][:TOP]))
            (out / f"interp_{fold}_seed{seed}.json").write_text(json.dumps(res, indent=1))
            f = res["features"]
            print(f"[{fold}|s{seed}] cover={res['coverage_all']:.2f} "
                  + " ".join(f"{names[i].split('__')[0][:5]}{names[i].split('__')[1][:4]}:"
                             f"rho={v['rho_pd_vs_first_layer']:.2f},M2={v['M_layer2']:.2f}"
                             for i, v in f.items())
                  + (f" | SHAPrho={res.get('spearman_shap_vs_I', float('nan')):.2f}"
                     f" top6={res.get('top6_overlap_shap', '-')}"), flush=True)


if __name__ == "__main__":
    main()
