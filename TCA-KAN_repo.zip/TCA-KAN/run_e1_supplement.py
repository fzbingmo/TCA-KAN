"""R2 supplement to E1 (PHM2010 leave-one-tool), two jobs in one pass.

1. Parameter-matched MLP. The E1 MLP baseline is 60-64-32-1 (6,017 parameters).
   This adds an MLP widened to 60-160-48-1 (17,537 parameters), within 0.2% of the
   plain KAN head (17,568), trained under the identical protocol (same split,
   standardization, full-batch AdamW, validation early stopping).
2. Model dump for the full-model interpretability analysis. TCA-KAN, plain KAN and
   the 6,017-parameter MLP are rebuilt in exactly the order run_experiments.run_fold
   constructs them after torch.manual_seed(seed), so their initial weights, and
   therefore the trained models, reproduce the E1 runs. Their state_dicts are saved
   and their RMSE is checked against results/full_raw/*.json when that is present.

Run (server):
  python run_e1_supplement.py --data-dir ../data/phm2010_raw --epochs 4000 \
         --seeds 0 1 2 3 4 5 6 7 8 9 --out results/e1_supp
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch

from src.data import Standardizer, build_context, load_features
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor
from run_experiments import (FOLDS, metrics, predict_torch, resolve_device,
                             train_torch, val_split)

MATCHED_HIDDEN = (160, 48)


def n_params(model):
    return sum(p.numel() for p in model.parameters())


def run_fold_seed(fold, seed, args, device, ref_dir, model_dir):
    train_exps, test_exps = FOLDS[fold]
    torch.manual_seed(seed); np.random.seed(seed)
    X, y, groups, names = load_features(args.data_dir, args.dataset)
    Xc = build_context(X, groups, k=5)
    tr_idx, va_idx = val_split(groups, train_exps)
    te_idx = np.where(np.isin(groups, test_exps))[0]
    sc = Standardizer().fit(X[tr_idx], y[tr_idx])
    Xs = sc.transform(X)
    Xcs = (Xc - sc.x_mean) / sc.x_std
    ys = (y - sc.y_mean) / sc.y_std

    # same construction order as run_experiments.run_fold -> identical inits
    replay = [("TCA-KAN (proposed)", TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5), Xcs),
              ("KAN (plain)", KANRegressor(X.shape[1], hidden=(32,), grid_size=5), Xs),
              ("MLP", MLPRegressor(X.shape[1]), Xs)]
    # the matched MLP gets its own reseeded init
    torch.manual_seed(seed); np.random.seed(seed)
    matched = MLPRegressor(X.shape[1], hidden=MATCHED_HIDDEN)

    res = {"fold": fold, "seed": seed, "models": {}}
    for name, model, Z in replay + [("MLP (matched)", matched, Xs)]:
        t0 = time.time()
        model, stopped = train_torch(model, Z[tr_idx], ys[tr_idx], Z[va_idx], ys[va_idx],
                                     args.epochs, device=device)
        pred = predict_torch(model, Z[te_idx], sc, device)
        res["models"][name] = {**metrics(pred, y[te_idx]), "params": n_params(model),
                               "stopped_epoch": stopped,
                               "train_seconds": round(time.time() - t0, 1)}
        if name != "MLP (matched)":
            tag = name.split()[0].replace("-", "")
            torch.save({k: v.detach().cpu() for k, v in model.state_dict().items()},
                       model_dir / f"{fold}_seed{seed}_{tag}.pt")

    # reproduction check against the original E1 json
    ref = ref_dir / f"phm2010_{fold}_seed{seed}.json"
    if ref.exists():
        old = json.loads(ref.read_text())["models"]
        res["repro_abs_diff_um"] = {
            n: abs(res["models"][n]["rmse"] - old[n]["rmse"]) * 1e3
            for n, _, _ in replay if n in old}
    np.savez_compressed(model_dir / f"{fold}_seed{seed}_scaler.npz",
                        x_mean=sc.x_mean, x_std=sc.x_std, y_mean=sc.y_mean,
                        y_std=sc.y_std, te_idx=te_idx, names=np.array(names))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="../data/phm2010_raw")
    ap.add_argument("--dataset", default="phm2010")
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--ref-dir", default="results/full_raw")
    ap.add_argument("--out", default="results/e1_supp")
    ap.add_argument("--device", default="auto")
    args = ap.parse_args()
    device = resolve_device(args.device)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    model_dir = out / "models"; model_dir.mkdir(exist_ok=True)
    print(f"device={device}")
    worst = 0.0
    for fold in args.folds:
        for seed in args.seeds:
            res = run_fold_seed(fold, seed, args, device, Path(args.ref_dir), model_dir)
            (out / f"e1supp_{fold}_seed{seed}.json").write_text(json.dumps(res, indent=2))
            msg = "  ".join(f"{n.split()[0]}{'(m)' if 'matched' in n else ''}="
                            f"{v['rmse']*1e3:.1f}" for n, v in res["models"].items())
            rep = res.get("repro_abs_diff_um")
            if rep:
                worst = max(worst, max(rep.values()))
                msg += f"  | repro max |d|={max(rep.values()):.3f} um"
            print(f"[{fold}|s{seed}] {msg}")
    print(f"\nmatched MLP params = {n_params(MLPRegressor(60, hidden=MATCHED_HIDDEN))}")
    print(f"worst reproduction deviation vs E1 json: {worst:.3f} um")


if __name__ == "__main__":
    main()
