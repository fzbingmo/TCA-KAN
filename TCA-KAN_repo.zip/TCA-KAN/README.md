# TCA-KAN: Interpretable Tool Wear Prediction in Milling

Code and result files accompanying the paper

> H. Zhao and J. Gao, *Interpretable Tool Wear Prediction in Milling with a
> Temporal-Context Attention Kolmogorov–Arnold Network*, Journal of the Brazilian Society
> of Mechanical Sciences and Engineering (manuscript BMSE-D-26-03377, under revision).

TCA-KAN is a temporal-context attention Kolmogorov–Arnold network for flank wear
regression. Sixty force and vibration features per cut are filtered by a depthwise temporal
convolution over the last *k* cuts, re-weighted by a squeeze-and-excitation style attention
gate, and mapped to flank wear through learnable B-spline edge functions. Every input keeps
an explicit univariate response curve, so the learned relations between features and wear
can be audited against cutting physics.

## Repository layout

```
src/                     model, feature extraction, and data loading
  kan.py                 KAN regressor (B-spline edges, response curves, sparsity statistics)
  model_proposed.py      TCA-KAN (depthwise temporal convolution + attention gate + KAN head)
  baselines.py           SVR / GBDT / CNN-BiLSTM / DResNet-1d / PSD-CVT
  train.py               MLP regressor and training helpers
  features.py            60 time-domain and spectral features (10 statistics x 6 channels)
  data.py                PHM2010 and MU-TCM loaders, missing-channel screening, context windows

Experiments
  run_experiments.py     E1, leave-one-tool cross-validation on PHM2010 (all models)
  run_e1_supplement.py   E1 parameter-matched MLP and dump of the E1 models (exact re-runs)
  run_mutcm_cv.py        E2, leave-one-cutting-condition-out on MU-TCM (per-seed output)
  run_transfer.py        E3, bidirectional transductive cross-dataset transfer,
                         zero-shot and few-shot with repeated draws
  run_ablation.py        ablation, components, context length k, grid size G, feature groups
  run_reg_sweep.py       L1 and entropy regularization sweep (sparsity metrics)
  run_noise.py           noise robustness, white Gaussian noise at prescribed SNR,
                         optional k sweep and parameter-matched MLP
  run_ebm_baseline.py    explainable boosting machine baseline on E1
  noise_bias_check.py    direction of the noise-induced error of the E1 models
  efficiency_bench.py    parameter count and single-thread CPU latency (Table 10)
  kan_compile.py         lossless compilation of the frozen splines to piecewise cubics
  compute_ai.py          cross-dataset agreement A_i of the spline curves

Analyses
  stratified_stats.py    tool-stratified Wilcoxon test (Stouffer combination) and within-tool
                         Cohen's d, used in the revised paper
  stats_tests.py         pooled Wilcoxon test of the first submission (kept for reference)
  interp_fullmodel.py    complete-model verification: partial dependence, second-layer
                         monotonicity, SHAP (expected gradients), TreeSHAP for GBDT
  interp_summary.py      summary of interp_fullmodel.py over all models
  perm_groups.py         grouped permutation importance of the complete model
  pd_energy.py           direction of the complete-model response to energy features
  ablation_stats.py, reg_stats.py, mutcm_inventory.py

Figures and tests
  make_figures.py, fig1_schematic.py, smoke_test.py

results/                 result files behind the tables and figures (see below)
```

## Environment

Python 3.8 or later. Install the dependencies with

```bash
pip install -r requirements.txt
```

The experiments of the paper were run with Python 3.8.8, PyTorch 1.13.1 (CUDA 11.7), and an
NVIDIA GeForce RTX 3060 Ti. The feature-driven models also train on a CPU, where a full
TCA-KAN fit takes about 20 s. The analyses of the complete model run on a CPU.

## Data

Neither dataset is redistributed here. Both are public:

- **PHM2010**, 2010 PHM Society Conference Data Challenge, high-speed milling, cutters c1,
  c4, and c6 with per-cut flank wear, force and vibration at 50 kHz.
  https://phmsociety.org/phm_competition/2010-phm-society-conference-data-challenge/
- **MU-TCM**, Mondragon Unibertsitatea face-milling dataset, DOI
  [10.48764/3hdp-gf23](https://doi.org/10.48764/3hdp-gf23), described in
  Peralta Abadia et al., Scientific Data 12, 855 (2025),
  [10.1038/s41597-025-05168-5](https://doi.org/10.1038/s41597-025-05168-5).
  Four of the 67 passes lack the external force and vibration channels and are excluded
  automatically by `src/data.py`, which leaves 63 passes.

The loaders cache the extracted features next to the raw data
(`phm2010_features_cache.npz`, `mutcm_features_signals_synced_cache.npz`). The analysis
scripts read these caches through their `--cache` argument.

## Reproducing the revised paper

| Paper item | Command | Results |
|---|---|---|
| Table 6, E1 | `python run_experiments.py --data-dir <phm2010> --epochs 4000 --seeds 0 1 2 3 4 5 6 7 8 9` | `full_raw/` |
| Table 6, parameter-matched MLP | `python run_e1_supplement.py --data-dir <phm2010> --seeds 0 1 2 3 4 5 6 7 8 9` | `e1_supp/` |
| Table 6, EBM | `python run_ebm_baseline.py --cache <phm2010 cache> --seeds 0 1 2 3 4 5 6 7 8 9` | `ebm/` |
| Table 6, p-values | `python stratified_stats.py e1 results/full_raw` | |
| Table 7, E2 | `python run_mutcm_cv.py --mutcm-dir <mutcm> --seeds 0 1 2 3 4 --mlp-matched` | `mutcm_cv_v2/` |
| Table 8, E3 | `python run_transfer.py --phm-dir <phm2010> --mutcm-dir <mutcm> --reverse --few-shot 10 --draws 5 --mlp-matched` | `transfer_v3/` |
| Table 9, ablation | `python run_ablation.py --data-dir <phm2010> --seeds 0 1 2 3 4 5 6 7 8 9` | `ablation_v2/` |
| Table 10, efficiency | `python efficiency_bench.py` | |
| Figure 2 | `python make_figures.py --fig2-panels-dir results/fig_dump` | `fig_dump/` |
| Figure 3 and Section 5.5 | `python run_noise.py --data-dir <phm2010> --seeds 0 1 2 3 4 5 6 7 8 9 --snrs clean 30 20 8 4 0 -4 --k-sweep --mlp-matched` | `noise_v2/` |
| Noise bias check | `python noise_bias_check.py --data-dir <phm2010> --models results/e1_supp/models` | `noise_bias.json` |
| Figure 4, A_i | `python compute_ai.py --mutcm-dir <mutcm>` | `fig_dump/` |
| Figure 5 and Section 5.7 | `python interp_fullmodel.py --cache <phm2010 cache> --models results/e1_supp/models --out results/interp`, `python perm_groups.py ...`, `python pd_energy.py ...`, then `python make_figures.py --fullmodel <cache> results/perm_groups.json results/interp results/e1_supp/models` | `interp/`, `perm_groups.json`, `pd_energy.json` |
| Regularization, Section 5.6 | `python run_reg_sweep.py --data-dir <phm2010>` | `reg_sweep/` |

Every experiment script enumerates folds and seeds internally, and the reported values are
mean ± 95% CI over the enumerated runs.

## Notes on the revision

- `run_e1_supplement.py` rebuilds the E1 models in the construction order of
  `run_experiments.py` and checks them against `results/full_raw`. On the original hardware
  all 30 runs reproduce the submitted E1 values exactly. The dumped models in
  `results/e1_supp/models` are the models analyzed in Section 5.7.
- `run_transfer.py` builds the temporal context on MU-TCM within each cutting edge. The
  first submission grouped it by workpiece material, and `--legacy-context` restores that
  grouping for provenance (`results/transfer_legacy`). Only the TCA-KAN entries of the
  transfer table depend on this choice.
- `results/noise` holds the five noise levels of the first submission, and
  `results/noise_v2` the seven levels of the revision, which reproduce them exactly.

## Citation

See `CITATION.cff`. The reference will be completed upon publication.

## License

MIT, see [LICENSE](LICENSE).
