"""Noise robustness (Figure 3): corrupt the raw test signals, re-extract features,
predict with the fixed feature-driven models.

Each model is trained once on the clean training tools (as in E1). At test time
the raw per-cut signals of the held-out tool are corrupted with additive white
Gaussian noise at a prescribed SNR, the 60 features are re-extracted from the
corrupted signals, and the trained models predict without any retraining -- so
the curve measures how much the feature representation, not the optimiser,
absorbs sensor noise. Feature-driven models only (TCA-KAN, plain KAN, MLP): they
share the feature front-end, isolating the head/context contribution to
robustness. Requires the raw 50 kHz layout (phm2010_raw).

Run (server):
  python run_noise.py --data-dir ../data/phm2010_raw --seeds 0 1 2 3 4 5 6 7 8 9 \
         --epochs 4000 --out results/noise

R2 extension (the defaults above are unchanged and reproduce the first-submission noise results exactly):
  --snrs clean 30 20 8 4 0 -4   adds the mild 30 and 20 dB levels
  --k-sweep                     adds TCA-KAN with k = 1, 3, 9 (k = 5 is the default model)
  --mlp-matched                 adds the parameter-matched MLP (60-160-48-1)
  python run_noise.py --data-dir ../data/phm2010_raw --seeds 0 1 2 3 4 5 6 7 8 9 \
         --epochs 4000 --snrs clean 30 20 8 4 0 -4 --k-sweep --mlp-matched \
         --out results/noise_v2
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from src.data import (CHANNELS, RAW_FS, Standardizer, _raw_cut_frames,
                      _raw_exp_dir, _raw_wear_mm, build_context, load_features)
from src.features import extract_features
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor
from run_experiments import (FOLDS, metrics, predict_torch, resolve_device,
                             train_torch, val_split)

SNRS = [None, 8, 4, 0, -4]        # None == clean baseline


def add_awgn(sig, snr_db, rng):
    if snr_db is None:
        return sig
    p_sig = np.mean(sig ** 2)
    p_noise = p_sig / (10.0 ** (snr_db / 10.0))
    return sig + rng.normal(0.0, np.sqrt(p_noise + 1e-30), size=sig.shape)


def test_features(data_dir, dataset, test_exp, snr, rng):
    """Re-extract the 60 features of the held-out tool's cuts under noise `snr`.
    Returns (X_test, y_test) in cut order."""
    exp_dir = _raw_exp_dir(data_dir, test_exp)
    wear = _raw_wear_mm(exp_dir, test_exp)
    X, y = [], []
    for i, df in _raw_cut_frames(data_dir, test_exp):
        if i >= len(wear):
            break
        noisy = df.copy()
        for ch in CHANNELS:
            noisy[ch] = add_awgn(df[ch].to_numpy(), snr, rng)
        X.append(extract_features(noisy, CHANNELS, RAW_FS))
        y.append(float(wear[i]))
    return np.stack(X), np.asarray(y, dtype=np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=r"..\data\phm2010_raw")
    ap.add_argument("--dataset", default="phm2010")
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--out", default="results/noise")
    ap.add_argument("--device", default="auto")
    ap.add_argument("--skip-existing", action="store_true")
    ap.add_argument("--snrs", nargs="+", default=None,
                    help="noise levels in dB, 'clean' for the uncorrupted baseline")
    ap.add_argument("--k-sweep", action="store_true",
                    help="also train TCA-KAN with context length k = 1, 3, 9")
    ap.add_argument("--mlp-matched", action="store_true",
                    help="also train the parameter-matched MLP (60-160-48-1)")
    args = ap.parse_args()
    snrs = SNRS if args.snrs is None else [None if v == "clean" else int(v) for v in args.snrs]
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    device = resolve_device(args.device)
    print(f"device={device}")

    for fold in args.folds:
        train_exps, test_exps = FOLDS[fold]
        test_exp = test_exps[0]
        for seed in args.seeds:
            path = out / f"noise_{fold}_seed{seed}.json"
            if args.skip_existing and path.exists():
                print(f"skip existing -> {path}"); continue
            torch.manual_seed(seed); np.random.seed(seed)
            X, y, groups, _ = load_features(args.data_dir, args.dataset)
            tr, va = val_split(groups, train_exps)
            sc = Standardizer().fit(X[tr], y[tr])
            Xs = sc.transform(X)
            ks = [5] + ([1, 3, 9] if args.k_sweep else [])
            Xcs = {kk: (build_context(X, groups, k=kk) - sc.x_mean) / sc.x_std for kk in ks}
            ys = (y - sc.y_mean) / sc.y_std
            d = X.shape[1]

            # train each feature-driven model once on the clean training tools;
            # the third entry is the context length (0 = single-cut input)
            specs = [("TCA-KAN (proposed)", lambda: TCAKAN(d, k=5, hidden=32, grid_size=5), 5),
                     ("KAN (plain)", lambda: KANRegressor(d, hidden=(32,), grid_size=5), 0),
                     ("MLP", lambda: MLPRegressor(d), 0)]
            if args.k_sweep:
                specs += [("TCA-KAN k=%d" % kk,
                           (lambda kk=kk: TCAKAN(d, k=kk, hidden=32, grid_size=5)), kk)
                          for kk in [1, 3, 9]]
            if args.mlp_matched:
                specs.append(("MLP (matched)", lambda: MLPRegressor(d, hidden=(160, 48)), 0))
            models = {}
            for name, factory, kk in specs:
                Z = Xcs[kk] if kk else Xs
                torch.manual_seed(seed); np.random.seed(seed)
                m, _ = train_torch(factory(), Z[tr], ys[tr], Z[va], ys[va],
                                   args.epochs, device=device)
                models[name] = (m, kk)

            res = {"fold": fold, "seed": seed, "rmse": {}}
            grp = np.array([test_exp])
            for snr in snrs:
                rng = np.random.default_rng(seed * 1000 + (999 if snr is None else snr + 100))
                Xt, yt = test_features(args.data_dir, args.dataset, test_exp, snr, rng)
                Xt_flat = (Xt - sc.x_mean) / sc.x_std
                Xt_ctx = {kk: (build_context(Xt, np.repeat(grp, len(Xt)), k=kk) - sc.x_mean)
                          / sc.x_std for kk in ks}
                key = "clean" if snr is None else f"{snr}dB"
                res["rmse"][key] = {}
                for name, (m, kk) in models.items():
                    pred = predict_torch(m, Xt_ctx[kk] if kk else Xt_flat, sc, device)
                    res["rmse"][key][name] = metrics(pred, yt)["rmse"] * 1e3
                print(f"  [{fold}|s{seed}] {key}: "
                      + "  ".join(f"{n}={res['rmse'][key][n]:.1f}" for n in models))
            path.write_text(json.dumps(res, indent=2))
            print(f"saved -> {path}")


if __name__ == "__main__":
    main()
