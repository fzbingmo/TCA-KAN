"""E3 cross-dataset transfer (Table 8): PHM2010 <-> MU-TCM on the shared 60-feature schema.

Both datasets are featurized by the identical extractor at 50 kHz, so a model
trained on one applies to the other with no feature-definition mismatch. We
report:
  * zero-shot PHM2010 -> MU-TCM  (train on all PHM2010, predict MU-TCM);
  * zero-shot MU-TCM  -> PHM2010 (reverse; needs enough MU-TCM data);
  * optional few-shot: add --few-shot N target passes to the training set.
For each direction we run the proposed TCA-KAN and the matched KAN/MLP baselines,
so the narrative can quote the retained-accuracy ratio against MLP transfer.

Context handling is automatic: build_context edge-pads within each group, so on
a target without per-tool wear trajectories (e.g. small_subset) the temporal
model degrades gracefully to single-cut (k=1) behaviour.

Run (server):
  python run_transfer.py --phm-dir ../data/phm2010_raw \
         --mutcm-dir ../data/mutcm_full/full_dataset --epochs 4000 \
         --seeds 0 1 2 3 4 --reverse --few-shot 10 --out results/transfer

R2 changes:
  * Temporal context on MU-TCM is now built per cutting edge (Insert_Edge from
    mutcm_metadata), so a context window never crosses from one edge into the
    next. The earlier version grouped MU-TCM by workpiece material, which let the
    first k-1 passes of an edge borrow passes of the previous edge. Only the
    context model (TCA-KAN) is affected; --legacy-context restores the old
    grouping for provenance. The validation split is unchanged (last 15% of each
    source group: PHM2010 tool, or MU-TCM workpiece material).
  * --draws R repeats the few-shot selection with R independent draws
    (draw r uses numpy default_rng(r); draw 0 is the original selection).
  * --mlp-matched adds the parameter-matched MLP (60-160-48-1).
  python run_transfer.py --phm-dir ../data/phm2010_raw \
         --mutcm-dir ../data/mutcm_full/full_dataset --epochs 4000 \
         --seeds 0 1 2 3 4 --reverse --few-shot 10 --draws 5 --mlp-matched \
         --out results/transfer_v3
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from src.data import (Standardizer, build_context, load_features,
                      load_mutcm_features, mutcm_metadata)
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor
from run_experiments import (metrics, predict_torch, resolve_device, train_torch,
                             val_split)

#: name -> (input kind, factory). "ctx" models consume the (N,k,d) context.
def model_specs(d, mlp_matched=False):
    specs = {
        "TCA-KAN (proposed)": ("ctx", lambda: TCAKAN(d, k=5, hidden=32, grid_size=5)),
        "KAN (plain)": ("flat", lambda: KANRegressor(d, hidden=(32,), grid_size=5)),
        "MLP": ("flat", lambda: MLPRegressor(d)),
    }
    if mlp_matched:     # R2: parameter-matched MLP, 60-160-48-1 (17,537 parameters)
        specs["MLP (matched)"] = ("flat", lambda: MLPRegressor(d, hidden=(160, 48)))
    return specs


def standardized_views(X, groups, x_mean, x_std):
    """Return (flat, ctx) design matrices standardized by the given feature stats."""
    flat = (X - x_mean) / x_std
    ctx = (build_context(X, groups, k=5) - x_mean) / x_std
    return flat, ctx


def train_predict(kind, factory, src_flat, src_ctx, ys_src, tr, va,
                  tgt_flat, tgt_ctx, sc, epochs, device, seed, extra=None):
    """Train one model on the source split, predict the target. extra, if given,
    is (flat, ctx, y_raw) target samples folded into training (few-shot)."""
    torch.manual_seed(seed); np.random.seed(seed)
    model = factory()
    Zsrc = src_ctx if kind == "ctx" else src_flat
    Xtr, ytr = Zsrc[tr], ys_src[tr]
    if extra is not None:
        ef, ec, ey = extra
        Zex = ec if kind == "ctx" else ef
        Xtr = np.concatenate([Xtr, Zex])
        ytr = np.concatenate([ytr, (ey - sc.y_mean) / sc.y_std])
    model, _ = train_torch(model, Xtr, ytr, Zsrc[va], ys_src[va], epochs, device=device)
    Ztgt = tgt_ctx if kind == "ctx" else tgt_flat
    return predict_torch(model, Ztgt, sc, device)


def run_direction(src, tgt, epochs, device, seeds, few_shot, draws=1, mlp_matched=False):
    """src/tgt are dicts with raw X, y, groups. Returns {phase: {model: [rmse_um]}}.

    Features are standardized per domain (source by source stats, target by its own
    unsupervised stats) so a sensor-scale gap between machines does not push the
    target features far outside the spline grid -- the failure mode of source-only
    normalization. Labels are calibrated with the source scaler (no target labels
    are used at zero-shot); the target's few-shot samples are normalized like the
    target test set, keeping training and evaluation in one consistent space."""
    sc = Standardizer().fit(src["X"], src["y"])          # source feature + label stats
    tx_mean, tx_std = tgt["X"].mean(0), tgt["X"].std(0) + 1e-8   # per-domain target features
    src_flat, src_ctx = standardized_views(src["X"], src["ctx_groups"], sc.x_mean, sc.x_std)
    tgt_flat, tgt_ctx = standardized_views(tgt["X"], tgt["ctx_groups"], tx_mean, tx_std)
    ys_src = (src["y"] - sc.y_mean) / sc.y_std
    tr, va = val_split(src["groups"], list(np.unique(src["groups"])), frac=0.15)

    specs = model_specs(src["X"].shape[1], mlp_matched)
    results = {"zero_shot": {}, "few_shot": {}, "few_shot_draws": {}, "shot_indices": []}
    for name, (kind, factory) in specs.items():
        for seed in seeds:
            pred = train_predict(kind, factory, src_flat, src_ctx, ys_src, tr, va,
                                 tgt_flat, tgt_ctx, sc, epochs, device, seed)
            results["zero_shot"].setdefault(name, []).append(
                metrics(pred, tgt["y"])["rmse"] * 1e3)

    if few_shot and len(tgt["y"]) > few_shot + 2:
        for r in range(draws):
            rng = np.random.default_rng(r)            # draw 0 = original selection
            idx = rng.permutation(len(tgt["y"]))
            shot, test = idx[:few_shot], idx[few_shot:]
            results["shot_indices"].append(sorted(int(i) for i in shot))
            extra = (tgt_flat[shot], tgt_ctx[shot], tgt["y"][shot])
            for name, (kind, factory) in specs.items():
                vals = []
                for seed in seeds:
                    pred = train_predict(kind, factory, src_flat, src_ctx, ys_src, tr, va,
                                         tgt_flat[test], tgt_ctx[test], sc, epochs, device,
                                         seed, extra=extra)
                    vals.append(metrics(pred, tgt["y"][test])["rmse"] * 1e3)
                results["few_shot_draws"].setdefault(name, []).append(vals)
                if r == 0:
                    results["few_shot"][name] = vals
    return results


def summarize(tag, block):
    print(f"\n=== {tag} ===")
    for phase in ["zero_shot", "few_shot", "few_shot_draws"]:
        res = block.get(phase)
        if not res:
            continue
        label = ("all draws x seeds" if phase == "few_shot_draws"
                 else "mean over seeds, draw 0" if phase == "few_shot" else "mean over seeds")
        print(f"  [{phase}] RMSE (um), {label}:")
        for m, vals in res.items():
            vals = np.ravel(vals)
            print(f"    {m:<22} {np.mean(vals):6.1f} +/- {np.std(vals):.1f}  (n={len(vals)})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phm-dir", default="../data/phm2010_raw")
    ap.add_argument("--mutcm-dir", default="../data/mutcm_small/small_subset")
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--few-shot", type=int, default=0, help="target passes folded into training")
    ap.add_argument("--reverse", action="store_true", help="also run MU-TCM -> PHM2010")
    ap.add_argument("--out", default="results/transfer")
    ap.add_argument("--device", default="auto")
    ap.add_argument("--draws", type=int, default=1,
                    help="R2: independent few-shot selections (draw r uses rng seed r)")
    ap.add_argument("--mlp-matched", action="store_true",
                    help="R2: also train the parameter-matched MLP")
    ap.add_argument("--legacy-context", action="store_true",
                    help="provenance only: group MU-TCM context by material as before R2")
    args = ap.parse_args()
    device = resolve_device(args.device)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    print(f"device={device}")

    Xp, yp, gp, names_p = load_features(args.phm_dir, "phm2010")
    Xm, ym, gm, names_m = load_mutcm_features(args.mutcm_dir)
    assert names_p == names_m, "feature schema mismatch between PHM2010 and MU-TCM"
    print(f"PHM2010: {Xp.shape}  MU-TCM: {Xm.shape}  (shared {len(names_p)} features)")
    if args.legacy_context:
        tool_m = gm
    else:
        tool_m = mutcm_metadata(args.mutcm_dir)["tool"]   # row-aligned with Xm
        assert len(tool_m) == len(Xm), "MU-TCM metadata/feature row mismatch"
    kind = "material, legacy" if args.legacy_context else "cutting edges"
    print(f"MU-TCM context groups: {len(set(tool_m))} ({kind})")
    phm = {"X": Xp, "y": yp, "groups": gp, "ctx_groups": gp}
    mut = {"X": Xm, "y": ym, "groups": gm, "ctx_groups": tool_m}

    all_results = {"config": vars(args)}
    fwd = run_direction(phm, mut, args.epochs, device, args.seeds, args.few_shot,
                        args.draws, args.mlp_matched)
    summarize("PHM2010 -> MU-TCM", fwd); all_results["phm_to_mutcm"] = fwd
    if args.reverse:
        rev = run_direction(mut, phm, args.epochs, device, args.seeds, args.few_shot,
                            args.draws, args.mlp_matched)
        summarize("MU-TCM -> PHM2010", rev); all_results["mutcm_to_phm"] = rev

    (out / "transfer_results.json").write_text(json.dumps(all_results, indent=2))
    print(f"\nsaved -> {out/'transfer_results.json'}")


if __name__ == "__main__":
    main()
