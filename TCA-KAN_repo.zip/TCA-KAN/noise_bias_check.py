"""R2: direction of the noise-induced error of the dumped E1 TCA-KAN models.

Additive noise raises every energy and amplitude feature by an amount set by the noise
power. If the complete model reads these features as wear, its predictions should be
biased upward under noise. For each fold and seed this script re-extracts the held-out
features at the requested SNR levels (same noise generator as run_noise.py) and reports
the mean signed error (prediction minus measured wear) and the relative change of the
spectral-energy features.
  python noise_bias_check.py --data-dir ../data/phm2010_raw --models results/e1_supp/models \
         --seeds 0 1 2 --snrs clean 8 0 --out results/noise_bias.json
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from src.data import build_context
from src.model_proposed import TCAKAN
from run_experiments import FOLDS
from run_noise import test_features


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="../data/phm2010_raw")
    ap.add_argument("--dataset", default="phm2010")
    ap.add_argument("--models", default="results/e1_supp/models")
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--snrs", nargs="+", default=["clean", "8", "0"])
    ap.add_argument("--out", default="results/noise_bias.json")
    args = ap.parse_args()
    snrs = [None if v == "clean" else int(v) for v in args.snrs]
    res = {}
    for fold in args.folds:
        test_exp = FOLDS[fold][1][0]
        for seed in args.seeds:
            tag = f"{fold}_seed{seed}"
            scz = np.load(Path(args.models) / f"{tag}_scaler.npz", allow_pickle=True)
            names = [str(n) for n in scz["names"]]
            e_idx = [i for i, n in enumerate(names) if n.endswith("spec_energy")]
            model = TCAKAN(len(names), k=5, hidden=32, grid_size=5)
            model.load_state_dict(torch.load(Path(args.models) / f"{tag}_TCAKAN.pt",
                                             map_location="cpu"))
            model.eval()
            res[tag] = {}
            clean_e = None
            for snr in snrs:
                rng = np.random.default_rng(seed * 1000 + (999 if snr is None else snr + 100))
                Xt, yt = test_features(args.data_dir, args.dataset, test_exp, snr, rng)
                xc = (build_context(Xt, np.repeat(np.array([test_exp]), len(Xt)), k=5)
                      - scz["x_mean"]) / scz["x_std"]
                with torch.no_grad():
                    p = model(torch.as_tensor(xc, dtype=torch.float32)).numpy()
                pred = p * scz["y_std"] + scz["y_mean"]
                err = (pred - yt) * 1e3
                e = Xt[:, e_idx].mean(0)
                if snr is None:
                    clean_e = e
                key = "clean" if snr is None else f"{snr}dB"
                res[tag][key] = {"mean_signed_error_um": float(err.mean()),
                                 "rmse_um": float(np.sqrt(np.mean(err ** 2))),
                                 "share_overestimated": float(np.mean(err > 0)),
                                 "energy_rel_change": float(np.mean(e / clean_e - 1.0))}
                print(tag, key, {k: round(v, 3) for k, v in res[tag][key].items()}, flush=True)
    Path(args.out).write_text(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
