"""R2: explainable boosting machine (EBM) as an intrinsically interpretable baseline on E1.

EBM is a generalized additive model with pairwise interactions (GA2M) fitted by
cyclic boosting. It runs under the identical E1 protocol as SVR and GBDT: the same
leave-one-tool folds, the same standardization fitted on the training cuts, the
same standardized labels, and a fit on the union of the training and validation
splits. Library defaults are used; only random_state follows the seed.

Run (local, from the PHM2010 raw feature cache):
  python run_ebm_baseline.py --cache <phm2010 data>/phm2010_features_cache.npz \
         --seeds 0 1 2 3 4 5 6 7 8 9 --out results/ebm
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
from interpret.glassbox import ExplainableBoostingRegressor

from src.data import Standardizer
from run_experiments import FOLDS, metrics, val_split


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", required=True)
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--out", default="results/ebm")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    z = np.load(args.cache, allow_pickle=True)
    X, y, groups, names = z["X"], z["y"], z["groups"], list(z["names"])
    for fold in args.folds:
        train_exps, test_exps = FOLDS[fold]
        tr, va = val_split(groups, train_exps)
        te = np.where(np.isin(groups, test_exps))[0]
        sc = Standardizer().fit(X[tr], y[tr])
        Xs = sc.transform(X); ys = (y - sc.y_mean) / sc.y_std
        fit_idx = np.concatenate([tr, va])
        for seed in args.seeds:
            t0 = time.time()
            ebm = ExplainableBoostingRegressor(random_state=seed, feature_names=names)
            ebm.fit(Xs[fit_idx], ys[fit_idx])
            pred = sc.inverse_y(ebm.predict(Xs[te]))
            res = {"fold": fold, "seed": seed,
                   "models": {"EBM": {**metrics(pred, y[te]),
                                      "train_seconds": round(time.time() - t0, 1)}}}
            # global term importances (mean absolute score) for the interpretability comparison
            res["term_importance"] = {n: float(v) for n, v in
                                      zip(ebm.term_names_, ebm.term_importances())}
            (out / f"ebm_{fold}_seed{seed}.json").write_text(json.dumps(res, indent=2))
            print(f"[{fold}|s{seed}] EBM RMSE {res['models']['EBM']['rmse']*1e3:.1f} um "
                  f"({res['models']['EBM']['train_seconds']} s)", flush=True)


if __name__ == "__main__":
    main()
