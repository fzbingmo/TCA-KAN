"""R2: direction test of the complete model for amplitude and energy features.

Partial dependence of the complete TCA-KAN (feature set to x in every context slot of
every test cut) is expressed in micrometers of predicted wear, so its direction is
identified, unlike a single hidden-unit curve. For each channel's spectral energy and
RMS, the script reports the Spearman correlation between the feature value and the
partial dependence and the increasing-direction monotonicity fraction. Flank-wear
mechanics (Eq. flankforce) predicts a rising response.
  python pd_energy.py --cache <phm2010 data>/phm2010_features_cache.npz \
         --models results/e1_supp/models --out results/pd_energy.json
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
from scipy import stats

from src.data import build_context
from src.model_proposed import TCAKAN


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", required=True)
    ap.add_argument("--models", required=True)
    ap.add_argument("--stats", nargs="+", default=["spec_energy", "rms", "kurtosis", "spec_centroid"])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    z = np.load(args.cache, allow_pickle=True)
    X, y, groups, names = z["X"], z["y"], z["groups"], list(z["names"])
    Xc = build_context(X, groups, k=5)
    res = {}
    for mp in sorted(Path(args.models).glob("*_TCAKAN.pt")):
        tag = mp.name.replace("_TCAKAN.pt", "")
        scz = np.load(Path(args.models) / f"{tag}_scaler.npz")
        sc = {k: scz[k] for k in scz.files}
        te = sc["te_idx"]
        xte = torch.as_tensor(((Xc - sc["x_mean"]) / sc["x_std"])[te], dtype=torch.float32)
        model = TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5)
        model.load_state_dict(torch.load(mp, map_location="cpu")); model.eval()
        out = {}
        for i, n in enumerate(names):
            if n.split("__")[1] not in args.stats:
                continue
            zc = xte[:, -1, i].numpy()
            grid = np.linspace(np.percentile(zc, 1), np.percentile(zc, 99), 40)
            pd = []
            with torch.no_grad():
                for g in grid:
                    xm = xte.clone(); xm[:, :, i] = float(g)
                    pd.append(float(model(xm).mean()) * sc["y_std"] * 1e3 + sc["y_mean"] * 1e3)
            pd = np.array(pd)
            out[n] = {"spearman": float(stats.spearmanr(grid, pd)[0]),
                      "M_up": float(np.mean(np.diff(pd) >= 0)),
                      "range_um": float(pd.max() - pd.min())}
        res[tag] = out
        print(tag, flush=True)
    Path(args.out).write_text(json.dumps(res, indent=1))
    for st in args.stats:
        rows = [(tag, n, v) for tag, o in res.items() for n, v in o.items() if n.endswith(st)]
        sp = np.array([v["spearman"] for _, _, v in rows])
        rg = np.array([v["range_um"] for _, _, v in rows])
        big = rg >= np.percentile(rg, 50)
        print(f"{st:14s} n={len(rows)} rising share {np.mean(sp > 0):.2f} | among the larger-effect "
              f"half rising {np.mean(sp[big] > 0):.2f}, median spearman {np.median(sp[big]):.2f}, "
              f"median range {np.median(rg[big]):.1f} um")
        for ch in sorted({n.split('__')[0] for _, n, _ in rows}):
            s = [v["spearman"] for _, n, v in rows if n.startswith(ch + "__")]
            r = [v["range_um"] for _, n, v in rows if n.startswith(ch + "__")]
            print(f"    {ch:12s} rising {np.mean(np.array(s) > 0):.2f}  median range {np.median(r):5.1f} um")


if __name__ == "__main__":
    main()
