"""R2: tool-stratified paired statistics (reviewer 1, comment 4).

Runs that share a held-out tool share test data, so the 30 fold x seed runs are not
independent. For every held-out tool the Wilcoxon signed-rank test is applied to the
10 seed-paired differences, the two-sided p is turned into a signed z score, and the
scores are combined with the (unweighted) Stouffer method. Cohen's d is computed
within each tool and averaged. Usage:
  python stratified_stats.py e1 results/full_raw
  python stratified_stats.py ablation results/ablation_v2
  python stratified_stats.py noise <dir with noise_*.json>
"""
import glob
import json
import sys
from pathlib import Path

import numpy as np
from scipy import stats

REF = "TCA-KAN (proposed)"


def stratified(ref, other):
    """ref/other: {tool: array over seeds}. Returns p, mean within-tool d, tools won."""
    zs, ds, won = [], [], 0
    for t in sorted(ref):
        a, b = np.asarray(ref[t]), np.asarray(other[t])
        d = b - a                                  # > 0 means the reference is better
        p = stats.wilcoxon(a, b).pvalue
        zs.append(stats.norm.isf(p / 2) * np.sign(np.median(d)))
        ds.append(d.mean() / d.std(ddof=1))
        won += d.mean() > 0
    z = sum(zs) / np.sqrt(len(zs))
    return 2 * stats.norm.sf(abs(z)), float(np.mean(ds)), int(won), len(ref)


def load(kind, folder):
    out = {}
    for f in glob.glob(str(Path(folder) / "*.json")):
        d = json.load(open(f))
        if kind == "e1":
            items = {m: v["rmse"] * 1e3 for m, v in d["models"].items()}
        elif kind == "ablation":
            items = {m: v["rmse"] * 1e3 for m, v in d["variants"].items()}
        else:                                      # noise: rmse[level][model] in um
            items = {f"{lvl}|{m}": v for lvl, mv in d["rmse"].items() for m, v in mv.items()}
        for m, v in items.items():
            out.setdefault(m, {}).setdefault(d["fold"], {})[d["seed"]] = v
    return {m: {t: [s[k] for k in sorted(s)] for t, s in tv.items()} for m, tv in out.items()}


def main():
    kind, folder = sys.argv[1], sys.argv[2]
    R = load(kind, folder)
    if kind == "noise":
        levels = sorted({k.split("|")[0] for k in R}, key=lambda s: (s != "clean", s))
        for lvl in levels:
            for m in sorted({k.split("|")[1] for k in R if k.startswith(lvl + "|")}):
                if m == REF:
                    continue
                p, d, w, n = stratified(R[f"{lvl}|{REF}"], R[f"{lvl}|{m}"])
                print(f"{lvl:6s} {m:24s} p={p:.2g}  d={d:.2f}  tools won {w}/{n}")
        return
    ref_key = REF if kind == "e1" else "comp/full"
    for m in sorted(R):
        if m == ref_key:
            continue
        p, d, w, n = stratified(R[ref_key], R[m])
        pooled = np.mean([v for t in R[m] for v in R[m][t]])
        print(f"{m:24s} pooled={pooled:5.1f}  p={p:.2g}  d={d:.2f}  tools won {w}/{n}")


if __name__ == "__main__":
    main()
