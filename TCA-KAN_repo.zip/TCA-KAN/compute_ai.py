"""Cross-dataset spline agreement A_i (Eq. 19) for Figure 4 / Section 5.6.

Fits TCA-KAN on the full MU-TCM feature cache (63 passes, identical 60-feature
schema, 50 kHz pipeline), extracts the layer-0 response curves of the six
features shown in Figure 4 (the PHM2010 top-attribution set), and computes the
range-normalized agreement A_i between the PHM2010 curve (server spline dump)
and the seed-averaged MU-TCM curve.

Tool identity is not stored in the feature cache, but the cache preserves
lexicographic file order, which groups every cutting edge into one contiguous
block; the block lengths follow from the inventory (per-edge VB trajectories)
minus the four excluded passes, and each block's VB multiset is verified
against the inventory before use -- any mismatch aborts. Within an edge, passes
are ordered by VB (flank wear is non-decreasing in time, so VB order is
chronological up to ties) and temporal context never crosses edges.

Run:  python compute_ai.py
"""
import argparse
from pathlib import Path

import numpy as np
import torch

from src.data import Standardizer, build_context
from src.model_proposed import TCAKAN
from run_experiments import train_torch

# (edge name, kept count, kept VB multiset) in lexicographic file order --
# from transfer_round4 logs/mutcm_inventory.txt minus mutcm_excluded_files.txt.
BLOCKS = [
    ("Insert0_Edge2", 3, [0.000, 0.000, 0.018]),
    ("Insert0_Edge3", 6, [0.000] * 6),
    ("Insert1_Edge1", 8, [0.132] * 2 + [0.137] * 4 + [0.139] * 2),
    ("Insert2_Edge1", 8, [0.120] * 2 + [0.123] * 2 + [0.125] * 4),
    ("Insert3_Edge1", 8, [0.202] * 2 + [0.206] * 4 + [0.213] * 2),
    ("Insert4_Edge1", 8, [0.201] * 2 + [0.202] * 2 + [0.211] * 2 + [0.242] * 2),
    ("Insert6_Edge1", 16, [0.272] * 2 + [0.274] + [0.276] * 2 + [0.281] * 2
                          + [0.284] + [0.287] * 4 + [0.291] * 4),
    ("Insert9_Edge1", 4, [0.000, 0.000, 0.030, 0.030]),
    ("Insert9_Edge2", 2, [0.000, 0.039]),
]


def reconstruct_tools(y):
    """Assign a tool label to every cache row and verify each block's VB
    multiset against the inventory; abort on any mismatch."""
    tools = np.empty(len(y), dtype=object)
    pos = 0
    for name, n, vbs in BLOCKS:
        block = y[pos:pos + n]
        if sorted(np.round(block, 3)) != sorted(np.round(vbs, 3)):
            raise SystemExit(f"VB multiset mismatch for {name}: "
                             f"{sorted(np.round(block,3))} vs {sorted(vbs)}")
        tools[pos:pos + n] = name
        pos += n
    assert pos == len(y), "block lengths do not cover the cache"
    return tools


def chrono_order(y, tools):
    """Within each tool block, order passes by VB ascending (chronological)."""
    order = np.arange(len(y))
    out = []
    for name, _, _ in BLOCKS:
        idx = order[tools == name]
        out.extend(idx[np.argsort(y[idx], kind="stable")])
    return np.array(out)


def range_norm(c):
    lo, hi = c.min(), c.max()
    return (c - lo) / (hi - lo) if hi > lo else np.zeros_like(c)


def agreement(a, b):
    """A_i of Eq. (14) on range-normalized curves sampled on a common grid."""
    a, b = range_norm(a), range_norm(b)
    return 1.0 - np.trapezoid(np.abs(a - b)) / np.trapezoid(np.abs(a) + np.abs(b))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", default=r"..\transfer_round4_20260720\data\mutcm_features_signals_synced_cache.npz")
    ap.add_argument("--phm-splines", default=r"results\fig_dump\c6_seed0_splines.npz")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--out", default=r"results\fig_dump\mutcm_overlay.npz")
    args = ap.parse_args()

    z = np.load(args.cache, allow_pickle=True)
    X, y, names = z["X"], z["y"].astype(float), [str(n) for n in z["names"]]
    tools = reconstruct_tools(y)
    order = chrono_order(y, tools)
    X, y, tools = X[order], y[order], tools[order]
    print(f"MU-TCM cache: {X.shape}, {len(BLOCKS)} edges verified against inventory")

    phm = np.load(args.phm_splines, allow_pickle=True)
    top = [int(i) for i in phm["top"]]
    phm_names = [str(n) for n in phm["names"]]
    assert phm_names == names, "feature schema mismatch between PHM dump and MU-TCM cache"

    # validation split: last 15% of each edge's passes (min 1)
    va = []
    for name, _, _ in BLOCKS:
        idx = np.where(tools == name)[0]
        va.extend(idx[-max(1, int(len(idx) * 0.15)):])
    va = np.array(va)
    tr = np.setdiff1d(np.arange(len(y)), va)

    sc = Standardizer().fit(X[tr], y[tr])
    Xc = (build_context(X, tools, k=5) - sc.x_mean) / sc.x_std
    ys = (y - sc.y_mean) / sc.y_std

    curves = {i: [] for i in top}
    for seed in args.seeds:
        torch.manual_seed(seed); np.random.seed(seed)
        model = TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5)
        model, stopped = train_torch(model, Xc[tr], ys[tr], Xc[va], ys[va],
                                     args.epochs, device="cpu")
        layer0 = model.kan.layers[0]
        w = layer0.spline_weight.detach().abs().mean(-1)
        for i in top:
            j_star = int(w[:, i].argmax())            # same j* protocol as the PHM dump
            xs, ys_curve = layer0.activation_curves(i, out_idx=j_star)
            curves[i].append(ys_curve)
        print(f"  seed {seed}: trained (stop @{stopped})")

    out = {"top": np.array(top), "names": np.array(names)}
    print(f"\n{'feature':<28}{'A_i':>8}{'flipped':>9}")
    for i in top:
        xs_phm, ys_phm = phm[f"x_{i}"], phm[f"y_{i}"]
        mu_mean = np.mean(curves[i], axis=0)          # same 200-pt grid on [-1.5, 1.5]
        # a hidden unit's sign is not identified across fits; align orientation
        flip = np.corrcoef(range_norm(ys_phm), range_norm(mu_mean))[0, 1] < 0
        mu_aligned = -mu_mean if flip else mu_mean
        ai = agreement(ys_phm, mu_aligned)
        out[f"mx_{i}"], out[f"my_{i}"] = xs_phm, mu_aligned
        out[f"ai_{i}"] = ai
        print(f"{names[i]:<28}{ai:>8.2f}{str(bool(flip)):>9}")
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out, **out)
    print(f"\nsaved -> {args.out}")


if __name__ == "__main__":
    main()
