"""R2: grouped permutation importance of the complete TCA-KAN (model-agnostic check).

For each dumped E1 model, the features of one group are permuted jointly across the
test cuts (one permutation shared by all features of the group and all context
slots), which keeps the correlation inside the group and breaks its relation to wear.
The importance of the group is the increase in test RMSE in micrometers, averaged over
`--reps` permutations. Groups are the ten statistics (each over six channels) and the
six channels (each over ten statistics).
  python perm_groups.py --cache <phm2010 data>/phm2010_features_cache.npz \
         --models results/e1_supp/models --out results/perm_groups.json
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from src.data import build_context
from src.model_proposed import TCAKAN


def rmse_um(model, Xcs, y, sc):
    with torch.no_grad():
        p = model(torch.as_tensor(Xcs, dtype=torch.float32)).numpy() * sc["y_std"] + sc["y_mean"]
    return float(np.sqrt(np.mean((p - y) ** 2)) * 1e3)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache", required=True)
    ap.add_argument("--models", required=True)
    ap.add_argument("--reps", type=int, default=10)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    z = np.load(args.cache, allow_pickle=True)
    X, y, groups, names = z["X"], z["y"], z["groups"], list(z["names"])
    Xc = build_context(X, groups, k=5)
    stat = np.array([n.split("__")[1] for n in names])
    chan = np.array([n.split("__")[0] for n in names])
    grp = {**{f"stat:{s}": np.where(stat == s)[0] for s in sorted(set(stat))},
           **{f"chan:{c}": np.where(chan == c)[0] for c in sorted(set(chan))}}
    res = {}
    for mp in sorted(Path(args.models).glob("*_TCAKAN.pt")):
        tag = mp.name.replace("_TCAKAN.pt", "")
        scz = np.load(Path(args.models) / f"{tag}_scaler.npz")
        sc = {k: scz[k] for k in scz.files}
        te = sc["te_idx"]
        Xte = ((Xc - sc["x_mean"]) / sc["x_std"])[te]
        model = TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5)
        model.load_state_dict(torch.load(mp, map_location="cpu")); model.eval()
        base = rmse_um(model, Xte, y[te], sc)
        rng = np.random.default_rng(0)
        out = {"base_rmse": base}
        for g, idx in grp.items():
            inc = []
            for _ in range(args.reps):
                Xp = Xte.copy()
                perm = rng.permutation(len(te))
                Xp[:, :, idx] = Xte[perm][:, :, idx]
                inc.append(rmse_um(model, Xp, y[te], sc) - base)
            out[g] = float(np.mean(inc))
        res[tag] = out
        s = {k: v for k, v in out.items() if k.startswith("stat:")}
        top = sorted(s, key=s.get, reverse=True)[:4]
        print(tag, f"base {base:.1f}", " ".join(f"{k[5:]}+{s[k]:.1f}" for k in top), flush=True)
    Path(args.out).write_text(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
