"""Regularization-strength sweep of TCA-KAN for the sparsity/interpretability story.

The ablation (Table 9) established that the L1--entropy penalty at its operating
strength (1e-5) is inert for accuracy. This sweep tests its actual role: does a
stronger penalty sparsify the learned KAN, and is 1e-5 effectively no penalty?
For each (fold, seed) we train the full TCA-KAN (k=5, G=5) at reg in
{0, 1e-5, 1e-4, 1e-3, 1e-2}, recording test RMSE/MAE and the KAN head's sparsity
statistics (l1, entropy, effective active edges, dead-edge fraction).

Every reg level reseeds immediately before construction (same RNG discipline as
run_ablation.py), so reg=0 and reg=1e-5 start from an identical init and any
divergence between them is the penalty's doing, not seed noise.

Run:  python run_reg_sweep.py --data-dir ../data/phm2010_raw --seeds 0 1 2 3 4 5 6 7 8 9 --epochs 4000
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from src.data import Standardizer, build_context, load_features
from src.model_proposed import TCAKAN
from run_experiments import (FOLDS, metrics, predict_torch, resolve_device,
                             train_torch, val_split)

REG_LEVELS = [0.0, 1e-5, 1e-4, 1e-3, 1e-2]


def run_one(reg, d, Xcs, ys, y, tr, va, te, sc, epochs, device, seed):
    # Reseed before construction so every reg level starts from an identical init
    # under the same seed; reg=0 vs reg=1e-5 then differ only by the penalty.
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = TCAKAN(d, k=5, hidden=32, grid_size=5)
    model, stopped = train_torch(model, Xcs[tr], ys[tr], Xcs[va], ys[va], epochs,
                                 reg=reg, device=device)
    pred = predict_torch(model, Xcs[te], sc, device)
    return {**metrics(pred, y[te]), "stopped_epoch": stopped, **model.sparsity_stats()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=r"..\data\uniwear-dataset\data")
    ap.add_argument("--dataset", default="phm2010")
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--epochs", type=int, default=4000)
    ap.add_argument("--out", default="results/reg_sweep")
    ap.add_argument("--device", default="auto",
                    help="auto, cpu, cuda, or a concrete torch device such as cuda:0")
    ap.add_argument("--skip-existing", action="store_true",
                    help="resume by skipping output JSON files that already exist")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    device = resolve_device(args.device)
    print(f"device={device}")

    for fold in args.folds:
        train_exps, test_exps = FOLDS[fold]
        for seed in args.seeds:
            path = out / f"reg_{fold}_seed{seed}.json"
            if args.skip_existing and path.exists():
                print(f"skip existing -> {path}")
                continue
            torch.manual_seed(seed); np.random.seed(seed)
            X, y, groups, names = load_features(args.data_dir, args.dataset)
            d = X.shape[1]
            tr, va = val_split(groups, train_exps)
            te = np.where(np.isin(groups, test_exps))[0]
            sc = Standardizer().fit(X[tr], y[tr])
            ys = (y - sc.y_mean) / sc.y_std
            Xcs = (build_context(X, groups, k=5) - sc.x_mean) / sc.x_std
            res = {"fold": fold, "seed": seed, "reg_sweep": {}}
            for reg in REG_LEVELS:
                res["reg_sweep"][f"{reg:g}"] = run_one(
                    reg, d, Xcs, ys, y, tr, va, te, sc, args.epochs, device, seed)
                r = res["reg_sweep"][f"{reg:g}"]
                print(f"  [{fold}|s{seed}] reg={reg:g}: RMSE {r['rmse']*1e3:.1f} um  "
                      f"l1={r['l1']:.2f}  eff_edges={r['eff_edges']:.1f}  "
                      f"dead={r['dead_frac']:.0%}")
            path.write_text(json.dumps(res, indent=2))
            print(f"saved -> {path}")


if __name__ == "__main__":
    main()
