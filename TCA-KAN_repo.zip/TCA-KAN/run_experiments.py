"""Unified experiment runner: proposed TCA-KAN vs all baselines on E1 folds.

Adds what the plain train.py lacked: a validation split (last 15% of each
training experiment's cuts) with early stopping, so long budgets cannot
overfit the way the 2000-epoch plain-KAN run did on fold c1.

Local smoke:  python run_experiments.py --epochs 600
Server full:  python run_experiments.py --data-dir ../data/phm2010_raw --epochs 4000 --seeds 0 1 2 3 4 5 6 7 8 9
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from src.baselines import CNNBiLSTM, DResNet1d, PSDCVT, fit_predict_sklearn, welch_psd
from src.data import (Standardizer, build_context, load_features, load_windows,
                      sampling_rate)
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor

FOLDS = {"c6": (["c1", "c4"], ["c6"]),
         "c4": (["c1", "c6"], ["c4"]),
         "c1": (["c4", "c6"], ["c1"])}


def resolve_device(device):
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    return torch.device(device)


def as_float_tensor(x, device):
    return torch.as_tensor(x, dtype=torch.float32, device=device)


@torch.no_grad()
def predict_torch(model, X, scaler, device):
    device = resolve_device(device)
    model.eval()
    model.to(device)
    pred = model(as_float_tensor(X, device)).detach().cpu().numpy()
    return scaler.inverse_y(pred)


def val_split(groups, train_exps, frac=0.15):
    """Last `frac` of each training experiment's cuts -> validation indices."""
    tr_idx, va_idx = [], []
    for g in train_exps:
        idx = np.where(groups == g)[0]
        n_va = max(1, int(len(idx) * frac))
        tr_idx.extend(idx[:-n_va]); va_idx.extend(idx[-n_va:])
    return np.array(tr_idx), np.array(va_idx)


def train_torch(model, X_tr, y_tr, X_va, y_va, epochs, lr=1e-3, reg=1e-5,
                patience=30, eval_every=10, device="auto"):
    device = resolve_device(device)
    model.to(device)
    X_tr_t = as_float_tensor(X_tr, device)
    y_tr_t = as_float_tensor(y_tr, device)
    X_va_t = as_float_tensor(X_va, device)
    y_va_t = as_float_tensor(y_va, device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    best_val, best_state, strikes = np.inf, None, 0
    for epoch in range(1, epochs + 1):
        model.train(); opt.zero_grad()
        loss = nn.functional.mse_loss(model(X_tr_t), y_tr_t)
        if reg and hasattr(model, "regularization_loss"):
            loss = loss + reg * model.regularization_loss()
        loss.backward(); opt.step()
        if epoch % eval_every == 0:
            model.eval()
            with torch.no_grad():
                val = nn.functional.mse_loss(model(X_va_t), y_va_t).item()
            if val < best_val - 1e-6:
                best_val, strikes = val, 0
                best_state = {k: v.detach().cpu().clone()
                              for k, v in model.state_dict().items()}
            else:
                strikes += 1
                if strikes >= patience:
                    break
    if best_state:
        model.load_state_dict(best_state)
    return model, epoch


def metrics(pred, y):
    return {"rmse": float(np.sqrt(np.mean((pred - y) ** 2))),
            "mae": float(np.mean(np.abs(pred - y)))}


def run_fold(fold, args, seed):
    train_exps, test_exps = FOLDS[fold]
    torch.manual_seed(seed); np.random.seed(seed)
    device = resolve_device(args.device)
    print(f"[{fold}|s{seed}] device={device}")
    results = {}

    # ---------------- feature-driven models ----------------
    X, y, groups, names = load_features(args.data_dir, args.dataset)
    Xc = build_context(X, groups, k=args.k)
    tr_idx, va_idx = val_split(groups, train_exps)
    te_idx = np.where(np.isin(groups, test_exps))[0]

    sc = Standardizer().fit(X[tr_idx], y[tr_idx])
    Xs = sc.transform(X)
    Xcs = (Xc - sc.x_mean) / sc.x_std
    ys = (y - sc.y_mean) / sc.y_std
    preds = {}                       # model -> test predictions (um), for the Figure 2 dump
    proposed_model = None            # captured for the Figure 4 spline dump

    torch_feature_models = {
        "TCA-KAN (proposed)": (TCAKAN(X.shape[1], k=args.k, hidden=32, grid_size=5), Xcs),
        "KAN (plain)": (KANRegressor(X.shape[1], hidden=(32,), grid_size=5), Xs),
        "MLP": (MLPRegressor(X.shape[1]), Xs),
    }
    for name, (model, Z) in torch_feature_models.items():
        t0 = time.time()
        model, stopped = train_torch(model, Z[tr_idx], ys[tr_idx], Z[va_idx], ys[va_idx],
                                     args.epochs, device=device)
        pred = predict_torch(model, Z[te_idx], sc, device)
        results[name] = {**metrics(pred, y[te_idx]),
                         "params": sum(p.numel() for p in model.parameters()),
                         "stopped_epoch": stopped,
                         "train_seconds": round(time.time() - t0, 1)}
        preds[name] = pred
        if name.startswith("TCA-KAN"):
            proposed_model = model
        print(f"  [{fold}|s{seed}] {name}: RMSE {results[name]['rmse']*1e3:.1f} um "
              f"(stop @{stopped})")

    for name in ["SVR", "GBDT"]:
        t0 = time.time()
        pred = fit_predict_sklearn(name, Xs[np.concatenate([tr_idx, va_idx])],
                                   ys[np.concatenate([tr_idx, va_idx])], Xs[te_idx])
        pred = sc.inverse_y(pred)
        results[name] = {**metrics(pred, y[te_idx]),
                         "train_seconds": round(time.time() - t0, 1)}
        preds[name] = pred
        print(f"  [{fold}|s{seed}] {name}: RMSE {results[name]['rmse']*1e3:.1f} um")

    # ---------------- end-to-end models ----------------
    W, yw, gw, channels = load_windows(args.data_dir, args.dataset, length=args.win_len)
    assert np.allclose(yw, y), "cut alignment mismatch between loaders"
    mu = W[tr_idx].mean((0, 2), keepdims=True); sd = W[tr_idx].std((0, 2), keepdims=True) + 1e-8
    Wn = (W - mu) / sd
    P = welch_psd(W, fs=sampling_rate(args.data_dir, args.dataset), n_bins=64)
    pmu = P[tr_idx].mean((0, 2), keepdims=True); psd_ = P[tr_idx].std((0, 2), keepdims=True) + 1e-8
    Pn = (P - pmu) / psd_

    torch_raw_models = {
        "CNN-BiLSTM": (CNNBiLSTM(len(channels)), Wn),
        "DResNet-1d": (DResNet1d(len(channels)), Wn),
        "PSD-CVT": (PSDCVT(len(channels)), Pn),
    }
    for name, (model, Z) in torch_raw_models.items():
        t0 = time.time()
        model, stopped = train_torch(model, Z[tr_idx], ys[tr_idx], Z[va_idx], ys[va_idx],
                                     args.epochs, lr=5e-4, device=device)
        pred = predict_torch(model, Z[te_idx], sc, device)
        results[name] = {**metrics(pred, y[te_idx]),
                         "params": sum(p.numel() for p in model.parameters()),
                         "stopped_epoch": stopped,
                         "train_seconds": round(time.time() - t0, 1)}
        preds[name] = pred
        print(f"  [{fold}|s{seed}] {name}: RMSE {results[name]['rmse']*1e3:.1f} um "
              f"(stop @{stopped})")

    if args.dump_dir and proposed_model is not None:
        dump_figure_data(Path(args.dump_dir), fold, seed, preds, y[te_idx],
                         proposed_model, names)
    return results


def dump_figure_data(dump_dir, fold, seed, preds, y_te, proposed_model, names):
    """Persist per-cut predictions (Figure 2) and TCA-KAN spline curves (Figure 4)."""
    dump_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(dump_dir / f"{fold}_seed{seed}_pred.npz",
                        y_te=y_te, names=np.array(names), **{
                            k.replace(" ", "_"): v for k, v in preds.items()})
    # Figure 4: evaluate the KAN head's first-layer response curves + M_i + I_i
    layer0 = proposed_model.kan.layers[0]
    w = layer0.spline_weight.detach().abs().mean(-1)          # (out, in) = I contributions
    attribution = w.sum(0).cpu().numpy()
    top = np.argsort(attribution)[::-1][:6]
    curves = {}
    for i in top:
        j_star = int(w[:, i].argmax().detach().cpu().item())
        xs, ys = layer0.activation_curves(int(i), out_idx=j_star)
        curves[f"x_{i}"] = xs; curves[f"y_{i}"] = ys
    np.savez_compressed(dump_dir / f"{fold}_seed{seed}_splines.npz",
                        top=top, attribution=attribution, names=np.array(names), **curves)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=r"..\data\uniwear-dataset\data")
    ap.add_argument("--dataset", default="phm2010")
    ap.add_argument("--folds", nargs="+", default=["c6", "c4", "c1"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[42])
    ap.add_argument("--epochs", type=int, default=600)
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--win-len", type=int, default=256)
    ap.add_argument("--out", default="results/full_comparison")
    ap.add_argument("--dump-dir", default=None,
                    help="if set, save per-cut predictions + TCA-KAN spline curves for figures")
    ap.add_argument("--device", default="auto",
                    help="auto, cpu, cuda, or a concrete torch device such as cuda:0")
    ap.add_argument("--skip-existing", action="store_true",
                    help="resume by skipping output JSON files that already exist")
    args = ap.parse_args()

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    for fold in args.folds:
        for seed in args.seeds:
            path = out / f"{args.dataset}_{fold}_seed{seed}.json"
            if args.skip_existing and path.exists():
                print(f"skip existing -> {path}")
                continue
            res = {"fold": fold, "seed": seed, "config": vars(args)}
            res["models"] = run_fold(fold, args, seed)
            path.write_text(json.dumps(res, indent=2))
            print(f"saved -> {path}")


if __name__ == "__main__":
    main()
