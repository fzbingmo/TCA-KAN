"""Summarize interp_fullmodel.py outputs over all fold x seed models (R2)."""
import glob
import json
import sys
from collections import Counter

import numpy as np

STATS = ["mean", "std", "rms", "peak", "p2p", "skewness", "kurtosis", "crest_factor",
         "spec_centroid", "spec_energy"]
AMP = ["std", "rms", "peak", "p2p", "spec_energy"]          # amplitude and energy
SHAPE = ["skewness", "kurtosis", "crest_factor", "spec_centroid"]  # distribution shape


def shares(vec, names):
    vec = np.asarray(vec)
    stat = np.array([n.split("__")[1] for n in names])
    tot = vec.sum()
    return {g: float(vec[np.isin(stat, members)].sum() / tot)
            for g, members in [("amplitude", AMP), ("shape", SHAPE), ("mean", ["mean"])]}


def main(folder):
    rows = [json.load(open(f)) for f in sorted(glob.glob(f"{folder}/interp_*.json"))]
    print(f"{len(rows)} models")
    names = rows[0]["names"]
    by_fold = {}
    top_shap, top_I = Counter(), Counter()
    rho_pd, m2, share_j, cov_feat, mpd, mfl = [], [], [], [], [], []
    for d in rows:
        I, S = np.array(d["I"]), np.array(d["shap_global"])
        f = by_fold.setdefault(d["fold"], {"sp": [], "ov": [], "gb": [], "I": [], "S": [], "cov": []})
        f["sp"].append(d["spearman_shap_vs_I"]); f["ov"].append(d["top6_overlap_shap"])
        f["gb"].append(d["spearman_treeshap_gbdt_vs_I"]); f["cov"].append(d["coverage_all"])
        f["I"].append(shares(I, names)); f["S"].append(shares(S, names))
        top_shap.update(names[i] for i in np.argsort(S)[::-1][:6])
        top_I.update(names[i] for i in np.argsort(I)[::-1][:6])
        for i, v in d["features"].items():
            rho_pd.append(abs(v["rho_pd_vs_first_layer"])); m2.append(v["M_layer2"])
            share_j.append(v["share_of_I_on_j_star"]); cov_feat.append(v["coverage"])
            mpd.append(v["M_pd"]); mfl.append(v["M_first_layer"])
    print("\nper fold: Spearman(SHAP,I) | top-6 overlap | Spearman(TreeSHAP GBDT,I) | "
          "amplitude share I/SHAP | shape share I/SHAP | coverage")
    for fold in sorted(by_fold):
        f = by_fold[fold]
        a = lambda key, g: np.mean([x[g] for x in f[key]])
        print(f"  {fold}: {np.mean(f['sp']):.2f} [{min(f['sp']):.2f},{max(f['sp']):.2f}] | "
              f"{np.mean(f['ov']):.1f} | {np.mean(f['gb']):.2f} | "
              f"{a('I','amplitude'):.2f}/{a('S','amplitude'):.2f} | "
              f"{a('I','shape'):.2f}/{a('S','shape'):.2f} | {np.mean(f['cov']):.2f}")
    allsp = [x for f in by_fold.values() for x in f["sp"]]
    print(f"  all: Spearman(SHAP,I) mean {np.mean(allsp):.2f}, range {min(allsp):.2f} to {max(allsp):.2f}")
    print("\nmost frequent top-6 by SHAP:", top_shap.most_common(8))
    print("most frequent top-6 by I_i :", top_I.most_common(8))
    q = lambda v: f"median {np.median(v):.2f}, IQR {np.percentile(v,25):.2f}-{np.percentile(v,75):.2f}"
    print(f"\ntop-6 features over all models (n={len(rho_pd)}):")
    print(f"  |rho| PD vs first layer: {q(rho_pd)}; share |rho|>0.9: {np.mean(np.array(rho_pd)>0.9):.2f}")
    print(f"  M layer-2 over observed input range: {q(m2)}; share >=0.9: {np.mean(np.array(m2)>=0.9):.2f}")
    print(f"  share of I_i on the dominant hidden unit: {q(share_j)}")
    print(f"  head-input coverage of [-1.5,1.5]: {q(cov_feat)}")
    print(f"  M first layer: {q(mfl)};  M of full-model PD: {q(mpd)}")


if __name__ == "__main__":
    main(sys.argv[1])
