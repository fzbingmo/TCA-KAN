"""Table 10 efficiency: parameter count and single-thread CPU inference latency.

Latency is the deployment-relevant metric (per-cut prediction on a shop-floor
CPU), so we measure it directly rather than quoting FLOPs -- standard FLOP
counters do not capture the KAN B-spline evaluation and would misrepresent the
proposed model. Each model is timed at its native input, batch size 1, on a
single CPU thread. Also reports the proposed model's CPU training time for the
retraining-feasibility claim.

Run:  python efficiency_bench.py [--reps 300] [--repeat 3]

R2: the raw-signal baselines are timed at the 2,048-sample windows used in the
experiments (run_experiments.py --win-len 2048); the first submission used 256-sample
windows here, which understated their latency. The parameter-matched MLP and the
compiled TCA-KAN (kan_compile.py) are included, and every latency is the median of
--repeat measurements of --reps runs, as in Table 10 of the revised paper.
"""
import argparse
import time

import numpy as np
import torch

from src.baselines import CNNBiLSTM, DResNet1d, PSDCVT
from src.kan import KANRegressor
from src.model_proposed import TCAKAN
from src.train import MLPRegressor

D, C, L, NBINS = 60, 6, 2048, 64     # features, raw channels, window length, PSD bins


def latency_ms(model, x, reps, warmup=25):
    model.eval()
    with torch.no_grad():
        for _ in range(warmup):
            model(x)
        t0 = time.perf_counter()
        for _ in range(reps):
            model(x)
        return (time.perf_counter() - t0) / reps * 1e3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=300)
    ap.add_argument("--repeat", type=int, default=3, help="measurements per model (median)")
    ap.add_argument("--train-time", action="store_true",
                    help="also measure TCA-KAN CPU training time on local features")
    args = ap.parse_args()
    torch.set_num_threads(1)
    torch.manual_seed(0)

    specs = [
        ("TCA-KAN (proposed)", TCAKAN(D, k=5, hidden=32, grid_size=5), torch.randn(1, 5, D)),
        ("KAN (plain)", KANRegressor(D, hidden=(32,), grid_size=5), torch.randn(1, D)),
        ("MLP", MLPRegressor(D), torch.randn(1, D)),
        ("MLP (matched)", MLPRegressor(D, hidden=(160, 48)), torch.randn(1, D)),
        ("CNN-BiLSTM", CNNBiLSTM(C), torch.randn(1, C, L)),
        ("DResNet-1d", DResNet1d(C), torch.randn(1, C, L)),
        ("PSD-CVT", PSDCVT(C), torch.randn(1, C, NBINS)),
    ]
    from kan_compile import compile_tcakan
    specs.insert(1, ("TCA-KAN (compiled)", compile_tcakan(specs[0][1]), torch.randn(1, 5, D)))
    print(f"single-thread CPU, batch=1, median of {args.repeat} x {args.reps} reps "
          f"(raw window L={L}, PSD bins={NBINS})\n")
    print(f"{'Model':<22}{'Params':>10}{'Latency (ms)':>16}")
    rows = []
    for name, model, x in specs:
        p = sum(t.numel() for t in model.parameters())
        ms = sorted(latency_ms(model, x, args.reps) for _ in range(args.repeat))[args.repeat // 2]
        rows.append((name, p, ms))
        print(f"{name:<22}{p:>10,}{ms:>16.3f}")

    print("\nLaTeX rows (Table 10):")
    for name, p, ms in rows:
        print(f"{name} & {p:,} & {ms:.2f} \\\\".replace(",", "{,}"))

    if args.train_time:
        from src.data import Standardizer, build_context, load_features
        from run_experiments import FOLDS, train_torch, val_split
        X, y, groups, _ = load_features(r"..\data\uniwear-dataset\data", "phm2010")
        tr_exps, te = FOLDS["c6"]
        tr, va = val_split(groups, tr_exps)
        sc = Standardizer().fit(X[tr], y[tr])
        Xc = (build_context(X, groups, k=5) - sc.x_mean) / sc.x_std
        ys = (y - sc.y_mean) / sc.y_std
        torch.manual_seed(0)
        model = TCAKAN(X.shape[1], k=5, hidden=32, grid_size=5)
        t0 = time.perf_counter()
        train_torch(model, Xc[tr], ys[tr], Xc[va], ys[va], epochs=4000, device="cpu")
        print(f"\nTCA-KAN single-thread CPU training (fold c6, local features): "
              f"{time.perf_counter() - t0:.1f} s")


if __name__ == "__main__":
    main()
